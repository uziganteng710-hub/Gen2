import 'dart:ui';
import 'package:flutter/material.dart';
import 'slide2.dart'; // DIUBAH: Mengarah ke Slide 2 terlebih dahulu

class SlidePage extends StatelessWidget {
  // Terima semua data yang dikirim dari SplashScreen
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SlidePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onHorizontalDragEnd: (details) {
          if (details.primaryVelocity != null) {
            // DIUBAH: Jika digeser ke kanan (velocity negatif/swipe ke kiri), masuk ke Slide 2
            if (details.primaryVelocity! < -300) {
              _navigateToSlide2(context);
            }
          }
        },
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF540808), // Merah Maroon Gelap Premium
                Color(0xFF330000), // Merah Hitam Pekat Velvet
                Color(0xFF0F0F0F), // Midnight Black
                Color(0xFF432020), // Dark Neon Red Accent
              ],
            ),
          ),
          child: Stack(
            children: [
              // Efek Ornamen Cahaya Merah Glow di Background
              Positioned(
                top: 40,
                right: -40,
                child: Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.redAccent.withOpacity(0.15),
                  ),
                ),
              ),

              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Spacer(),
                      
                      // ================= HEADER BRANDING =================
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.verified_user_rounded, color: Colors.redAccent, size: 32),
                          const SizedBox(width: 8),
                          Text(
                            "VOREX",
                            style: TextStyle(
                              fontSize: 22, // Disesuaikan sedikit agar muat di semua ukuran layar
                              fontWeight: FontWeight.bold, 
                              color: Colors.white.withOpacity(0.95), 
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 30),

                      // ================= CARD PESAN UTAMA (GLASSMORPHISM MERAH) =================
                      ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                          child: Container(
                            padding: const EdgeInsets.all(24.0),
                            decoration: BoxDecoration(
                              color: Colors.red.shade900.withOpacity(0.2), // Menggunakan tinta merah transparan
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: Colors.redAccent.withOpacity(0.3), width: 1.5), // Border merah menyala halus
                            ),
                            child: const Text(
                              "Hai, Sedikit info larangan, jangan pernah atau jangan pernah ada orang barter, share free dll, untuk peringatan saja,band + dell + no reffund sentuhan saja.",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15, 
                                height: 1.6, 
                                color: Colors.white, 
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ),
                      
                      const Spacer(),

                      // ================= PETUNJUK AKSES SWIPE =================
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white.withOpacity(0.3), size: 16),
                              Icon(Icons.arrow_forward_ios_rounded, color: Colors.redAccent.withOpacity(0.6), size: 24),
                              const Icon(Icons.arrow_forward_ios_rounded, color: Colors.redAccent, size: 24),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            "Geser Layar untuk Lanjut ke Slide Kedua",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7), 
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // DIUBAH: Fungsi navigasi berantai menuju Slide2Page dengan membawa seluruh parameter
  void _navigateToSlide2(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => Slide2Page(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          listBug: listBug,
          listDoos: listDoos,
          news: news,
        ),
      ),
    );
  }
}
