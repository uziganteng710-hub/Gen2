import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── SPIDER WEB PATTERN PAINTER (LATAR BERJARING TRANSPARAN) ─────────────────
class _SpiderWebPainter extends CustomPainter {
  final Color color;
  const _SpiderWebPainter({this.color = Colors.white24});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    final center = Offset(size.width * 0.85, size.height * 0.15);
    final maxRadius = size.longestSide * 1.2;

    const strands = 12;
    final angles = <double>[];
    for (int i = 0; i < strands; i++) {
      final angle = math.pi + (i * (math.pi * 0.5 / (strands - 1)));
      angles.add(angle);
    }

    for (final angle in angles) {
      final dx = center.dx + maxRadius * math.cos(angle);
      final dy = center.dy + maxRadius * math.sin(angle);
      canvas.drawLine(center, Offset(dx, dy), paint);
    }

    const rings = 8;
    for (int r = 1; r <= rings; r++) {
      final radius = maxRadius * (r / rings);
      final path = Path();
      for (int i = 0; i < angles.length; i++) {
        final dx = center.dx + radius * math.cos(angles[i]);
        final dy = center.dy + radius * math.sin(angles[i]);
        if (i == 0) {
          path.moveTo(dx, dy);
        } else {
          path.lineTo(dx, dy);
        }
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SpiderWebPainter oldDelegate) =>
      oldDelegate.color != color;
}

// ─── PUBLIC CHAT PAGE (FULL FIX & ANTI-ERROR) ────────────────────────────────
class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const PublicChatPage({
    super.key,
    this.sessionKey = '',
    this.username = 'User',
    this.role = 'Member',
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  int _onlineCount = 0;

  Timer? _pollingTimer;
  Timer? _onlineTimer;
  String? _lastMessageId;

  // BASE URL TERHUBUNG LANGSUNG KE DOMAIN & PORT
  final String _baseUrl =
      "http://host.asta-official.my.id:9471";

  // COLOR PALETTE (PURPLE - GREEN NEON - GLASS)
  static const Color bgDark = Color(0xFF07050E);
  static const Color accentPurple = Color(0xFFA855F7);
  static const Color accentGreen = Color(0xFF10B981);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);

  LinearGradient get purpleGreenGradient => const LinearGradient(
        colors: [Color(0xFFA855F7), Color(0xFF10B981)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _startPolling();
    _fetchOnlineUsers();
    _startOnlinePolling();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _onlineTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _checkNewMessages();
    });
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _fetchOnlineUsers();
    });
  }

  Future<void> _checkNewMessages() async {
    if (_lastMessageId == null) return;

    try {
      final response = await http
          .get(
            Uri.parse(
                '$_baseUrl/getPublicChat?key=${widget.sessionKey}&lastId=$_lastMessageId'),
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final newMessages = (data['messages'] as List)
              .map((item) => ChatMessage.fromJson(item))
              .toList();

          if (newMessages.isNotEmpty) {
            setState(() {
              _messages.insertAll(0, newMessages);
              _lastMessageId = _messages.first.id;
            });
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);

    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}'),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _messages = (data['messages'] as List)
                .map((item) => ChatMessage.fromJson(item))
                .toList();
            if (_messages.isNotEmpty) {
              _lastMessageId = _messages.first.id;
            }
          });
        } else {
          _showSnackBar(data['message'] ?? 'Gagal memuat pesan', isError: true);
        }
      } else {
        _showSnackBar('Gagal terhubung ke server (${response.statusCode})', isError: true);
      }
    } catch (e) {
      _showSnackBar('Koneksi lambat atau terputus', isError: true);
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
        _scrollToBottom();
      }
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http
          .get(
            Uri.parse('$_baseUrl/getOnlineUsers?key=${widget.sessionKey}'),
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _onlineCount = data['count'] ?? 0;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    setState(() => _isSending = true);

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/sendPublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'message': message,
        }),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        _messageController.clear();
        final newMessage = ChatMessage.fromJson(data['message']);
        setState(() {
          _messages.insert(0, newMessage);
          _lastMessageId = newMessage.id;
        });
        _scrollToBottom();
      } else {
        _showSnackBar(data['message'] ?? 'Gagal mengirim pesan', isError: true);
      }
    } catch (e) {
      _showSnackBar('Gagal mengirim pesan. Periksa jaringan Anda.', isError: true);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _deleteMessage(String messageId, String messageUsername) async {
    final canDelete =
        widget.role.toLowerCase() == 'owner' || widget.username == messageUsername;

    if (!canDelete) {
      _showSnackBar('Tidak bisa menghapus pesan orang lain', isError: true);
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF0F0921).withOpacity(0.95),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: accentPurple.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: accentPurple.withOpacity(0.25),
                blurRadius: 20,
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: accentPurple.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: accentPurple.withOpacity(0.3)),
                ),
                child: const Icon(Icons.delete_sweep_rounded,
                    color: accentPurple, size: 30),
              ),
              const SizedBox(height: 16),
              const Text(
                "HAPUS PESAN",
                style: TextStyle(
                  color: primaryWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Apakah Anda yakin ingin menghapus pesan ini?",
                style: TextStyle(color: softGrey, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context, false),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Center(
                          child: Text(
                            "BATAL",
                            style: TextStyle(
                                color: softGrey, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context, true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          gradient: purpleGreenGradient,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Center(
                          child: Text(
                            "HAPUS",
                            style: TextStyle(
                                color: primaryWhite,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirm != true) return;

    try {
      final response = await http.delete(
        Uri.parse('$_baseUrl/deletePublicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'messageId': messageId,
        }),
      );

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        setState(() {
          _messages.removeWhere((m) => m.id == messageId);
        });
        _showSnackBar('Pesan berhasil dihapus', isError: false);
      } else {
        _showSnackBar(data['message'] ?? 'Gagal menghapus pesan', isError: true);
      }
    } catch (_) {
      _showSnackBar('Gagal menghapus pesan', isError: true);
    }
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(color: primaryWhite, fontWeight: FontWeight.w500),
        ),
        backgroundColor: isError
            ? Colors.red.withOpacity(0.85)
            : accentGreen.withOpacity(0.85),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
        return accentPurple;
      case 'admin':
        return Colors.orangeAccent;
      case 'vip':
        return Colors.pinkAccent;
      default:
        return accentGreen;
    }
  }

  // --- SHEET RIWAYAT CHAT (BOTTOM SHEET) ---
  void _showHistorySheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.7,
          decoration: BoxDecoration(
            color: const Color(0xFF0C0719).withOpacity(0.96),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: accentPurple.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: accentGreen.withOpacity(0.2),
                blurRadius: 20,
                spreadRadius: 2,
              )
            ],
          ),
          child: Column(
            children: [
              const SizedBox(height: 12),
              Container(
                width: 42,
                height: 4.5,
                decoration: BoxDecoration(
                  color: Colors.white30,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.history_rounded, color: accentGreen, size: 22),
                  const SizedBox(width: 8),
                  Text(
                    'RIWAYAT CHAT PUBLIC',
                    style: TextStyle(
                      color: primaryWhite,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(color: accentGreen.withOpacity(0.8), blurRadius: 10),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Divider(color: Colors.white12, height: 1),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _messages.length,
                  separatorBuilder: (_, __) => const Divider(color: Colors.white10),
                  itemBuilder: (context, index) {
                    final msg = _messages[index];
                    return ListTile(
                      dense: true,
                      leading: CircleAvatar(
                        backgroundColor: accentPurple.withOpacity(0.25),
                        child: Text(
                          msg.username.isNotEmpty
                              ? msg.username[0].toUpperCase()
                              : '?',
                          style: const TextStyle(
                              color: accentPurple, fontWeight: FontWeight.bold),
                        ),
                      ),
                      title: Text(
                        msg.username,
                        style: TextStyle(
                            color: _getRoleColor(msg.role),
                            fontWeight: FontWeight.bold,
                            fontSize: 13),
                      ),
                      subtitle: Text(
                        msg.message,
                        style: const TextStyle(color: Colors.white70, fontSize: 12.5),
                      ),
                      trailing: Text(
                        msg.formattedTime,
                        style: const TextStyle(color: Colors.white38, fontSize: 10),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // Background Jaring-Jaring Transparan
          Positioned.fill(
            child: CustomPaint(
              painter: _SpiderWebPainter(color: Colors.white.withOpacity(0.08)),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: _isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: accentPurple, strokeWidth: 2.5),
                        )
                      : _messages.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.chat_bubble_outline_rounded,
                                      size: 54, color: Colors.white.withOpacity(0.3)),
                                  const SizedBox(height: 12),
                                  const Text('Belum ada pesan',
                                      style: TextStyle(color: softGrey, fontSize: 14)),
                                ],
                              ),
                            )
                          : ListView.builder(
                              controller: _scrollController,
                              reverse: true,
                              padding: const EdgeInsets.all(12),
                              itemCount: _messages.length,
                              itemBuilder: (context, index) {
                                final msg = _messages[index];
                                final isMe = msg.username == widget.username;
                                return GestureDetector(
                                  onLongPress: () =>
                                      _deleteMessage(msg.id, msg.username),
                                  child: _buildMessageBubble(msg, isMe),
                                );
                              },
                            ),
                ),
                _buildInputArea(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- HEADER: VOREXX CHAT & GARIS TIGA RIWAYAT ---
  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          width: 1.5,
          color: accentPurple.withOpacity(0.6),
        ),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withOpacity(0.18),
            blurRadius: 16,
            spreadRadius: 1,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: primaryWhite, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // TEKS BESAR UNGU BIRU: VOREXX CHAT
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Color(0xFFA855F7), Color(0xFF3B82F6)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ).createShader(bounds),
                      child: const Text(
                        "VOREXX CHAT",
                        style: TextStyle(
                          color: primaryWhite,
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: const BoxDecoration(
                            color: accentGreen,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Live • $_onlineCount Online",
                          style: const TextStyle(color: Colors.white60, fontSize: 11),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // GARIS TIGA UNTUK RIWAYAT CHAT
              GestureDetector(
                onTap: _showHistorySheet,
                child: Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: accentGreen.withOpacity(0.5)),
                  ),
                  child: const Icon(Icons.menu_rounded,
                      color: primaryWhite, size: 22),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- BUBBLE PESAN PUTIH TRANSPARAN BERJARING + BORDER UNGU HIJAU ---
  Widget _buildMessageBubble(ChatMessage msg, bool isMe) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isMe) ...[
            Container(
              width: 38,
              height: 38,
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                gradient: purpleGreenGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  msg.username.isNotEmpty ? msg.username[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: primaryWhite,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.76,
              ),
              // Bingkai Ungu Hijau Campur
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isMe ? 18 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 18),
                ),
                gradient: purpleGreenGradient,
                boxShadow: [
                  BoxShadow(
                    color: (isMe ? accentPurple : accentGreen).withOpacity(0.2),
                    blurRadius: 10,
                  )
                ],
              ),
              padding: const EdgeInsets.all(1.5), // Ketebalan border
              child: ClipRRect(
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16.5),
                  topRight: const Radius.circular(16.5),
                  bottomLeft: Radius.circular(isMe ? 16.5 : 2.5),
                  bottomRight: Radius.circular(isMe ? 2.5 : 16.5),
                ),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12), // Putih Transparan
                    ),
                    child: Stack(
                      children: [
                        // Pattern Jaring
                        Positioned.fill(
                          child: CustomPaint(
                            painter:
                                _SpiderWebPainter(color: Colors.white.withOpacity(0.12)),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (!isMe)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      msg.username,
                                      style: TextStyle(
                                        color: _getRoleColor(msg.role),
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    if (msg.role.toLowerCase() == 'owner') ...[
                                      const SizedBox(width: 6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: accentPurple.withOpacity(0.3),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: const Text(
                                          "OWNER",
                                          style: TextStyle(
                                            color: primaryWhite,
                                            fontSize: 8,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            Text(
                              msg.message,
                              style: const TextStyle(
                                  color: primaryWhite, fontSize: 13.5, height: 1.35),
                            ),
                            const SizedBox(height: 4),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Text(
                                msg.formattedTime,
                                style: TextStyle(
                                  color: primaryWhite.withOpacity(0.55),
                                  fontSize: 9.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- INPUT AREA ---
  Widget _buildInputArea() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 6, 14, 14),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: accentPurple.withOpacity(0.5), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withOpacity(0.15),
            blurRadius: 12,
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Row(
            children: [
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _messageController,
                  style: const TextStyle(color: primaryWhite, fontSize: 13.5),
                  cursorColor: accentGreen,
                  decoration: const InputDecoration(
                    hintText: "Tulis pesan di Vorexx Chat...",
                    hintStyle: TextStyle(color: Colors.white38, fontSize: 12.5),
                    border: InputBorder.none,
                  ),
                  onSubmitted: (_) => _sendMessage(),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _isSending ? null : _sendMessage,
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: purpleGreenGradient,
                    boxShadow: [
                      BoxShadow(
                        color: accentPurple.withOpacity(0.4),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Center(
                    child: _isSending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                color: primaryWhite, strokeWidth: 2),
                          )
                        : const Icon(Icons.send_rounded,
                            color: primaryWhite, size: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── MODEL CHAT MESSAGE ───────────────────────────────────────────────────────
class ChatMessage {
  final String id;
  final String username;
  final String role;
  final String message;
  final String timestamp;
  final String formattedTime;

  ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.message,
    required this.timestamp,
    required this.formattedTime,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      role: json['role'] ?? 'member',
      message: json['message'] ?? '',
      timestamp: json['timestamp'] ?? DateTime.now().toIso8601String(),
      formattedTime: json['formattedTime'] ?? '',
    );
  }
}
