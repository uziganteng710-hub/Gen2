// landing.dart
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';
import 'splash.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  VideoPlayerController? _bannerController;
  bool _bannerReady = false;

  // --- MODERN RED THEME (sama dengan dashboard) ---
  static const Color bgDark = Color(0xFF0A0E27);
  static const Color accentRed = Color(0xFFF44336);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color softRed = Color(0xFFEF5350);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);

  LinearGradient get redGradient => const LinearGradient(
        colors: [Color(0xFFF44336), Color(0xFFB71C1C)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );

    _animationController.forward();
    _initBannerVideo();
  }

  Future<void> _initBannerVideo() async {
    try {
      _bannerController = VideoPlayerController.asset('assets/videos/landing.mp4');
      await _bannerController!.initialize();
      _bannerController!
        ..setLooping(true)
        ..setVolume(0)
        ..play();
      if (mounted) setState(() => _bannerReady = true);
    } catch (e) {
      debugPrint('Banner video error: $e');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _bannerController?.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [accentRed.withOpacity(0.15), bgDark, bgDark],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: CustomPaint(
          painter: _GridPainter(),
          child: SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      children: [
                        const SizedBox(height: 24),

                        // ========== TOP BAR: LOGO + V7 PREM BADGE ==========
                        _buildTopBar(),

                        const SizedBox(height: 24),

                        // ========== BANNER VIDEO "VOREX EXECUTOR" ==========
                        _buildBannerVideo(),

                        const SizedBox(height: 28),

                        // ========== TOMBOL ENTER LOGIN ==========
                        _buildEnterLoginButton(),

                        const SizedBox(height: 16),

                        // ========== TOMBOL BUY ACCESS ==========
                        _buildBuyButton(),

                        const SizedBox(height: 32),

                        // ========== FEATURE LIST (VERTIKAL) ==========
                        _buildFeatureList(),

                        const SizedBox(height: 36),

                        // ========== JOIN OUR COMMUNITY ==========
                        _buildCommunitySection(),

                        const SizedBox(height: 24),

                        // ========== FOOTER ==========
                        _buildFooter(),

                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== TOP BAR (LOGO + BADGE) ====================
  Widget _buildTopBar() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(opacity: value, child: child);
      },
      child: Row(
        children: [
          // Logo kotak dengan glow
          Container(
            width: 64,
            height: 64,
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: primaryWhite.withOpacity(0.5), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: primaryWhite.withOpacity(0.25),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(
                "assets/images/logo.png",
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: darkRed.withOpacity(0.6),
                    child: const Icon(Icons.shield_rounded, color: primaryWhite, size: 28),
                  );
                },
              ),
            ),
          ),
          const Spacer(),
          // Badge V7 PREM
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryWhite.withOpacity(0.95), primaryWhite.withOpacity(0.75)],
              ),
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: primaryWhite.withOpacity(0.35),
                  blurRadius: 14,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.rocket_launch_rounded, color: darkRed, size: 15),
                const SizedBox(width: 8),
                const Text(
                  "V7 PREM",
                  style: TextStyle(
                    color: darkRed,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BANNER VIDEO ====================
  Widget _buildBannerVideo() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 700),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.scale(scale: 0.96 + (0.04 * value), child: child),
        );
      },
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: primaryWhite.withOpacity(0.6), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: primaryWhite.withOpacity(0.2),
              blurRadius: 24,
              spreadRadius: 1,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: AspectRatio(
            aspectRatio: 4 / 5,
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Video banner
                (_bannerReady && _bannerController != null)
                    ? FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _bannerController!.value.size.width,
                          height: _bannerController!.value.size.height,
                          child: VideoPlayer(_bannerController!),
                        ),
                      )
                    : Container(
                        color: darkRed.withOpacity(0.5),
                        child: const Center(
                          child: Icon(Icons.movie_creation_rounded,
                              color: primaryWhite, size: 48),
                        ),
                      ),
                // Overlay gradasi biar teks kebaca
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.15),
                        Colors.black.withOpacity(0.65),
                      ],
                      stops: const [0.0, 0.55, 1.0],
                    ),
                  ),
                ),
                // Judul VOREX EXECUTOR
                Positioned(
                  left: 20,
                  right: 20,
                  bottom: 22,
                  child: Text(
                    "VOREX EXECUTOR",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: primaryWhite,
                      letterSpacing: 1.5,
                      shadows: [
                        Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 12),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== ENTER LOGIN BUTTON ====================
  Widget _buildEnterLoginButton() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 500),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: GestureDetector(
          onTap: () {
            Navigator.pushNamed(context, "/login");
          },
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryWhite.withOpacity(0.95), primaryWhite.withOpacity(0.8)],
              ),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: primaryWhite.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.arrow_forward_rounded, color: darkRed, size: 20),
                  SizedBox(width: 12),
                  Text(
                    "ENTER LOGIN",
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: darkRed,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== BUY ACCESS BUTTON ====================
  Widget _buildBuyButton() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 55,
        child: GestureDetector(
          onTap: () => _openUrl("https://t.me/ThisDevZenn"),
          child: Container(
            decoration: BoxDecoration(
              color: glassPrimary,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: primaryWhite.withOpacity(0.3), width: 1.3),
            ),
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shopping_cart_rounded, color: primaryWhite, size: 18),
                  SizedBox(width: 12),
                  Text(
                    "BUY ACCESS",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: primaryWhite,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== FEATURE LIST (VERTIKAL, SESUAI FOTO) ====================
  Widget _buildFeatureList() {
    return Column(
      children: [
        _buildFeatureTile(
          icon: Icons.bolt_rounded,
          title: "ULTRA FAST",
          desc: "Lightning speed performance",
          delay: 0,
        ),
        const SizedBox(height: 14),
        _buildFeatureTile(
          icon: Icons.shield_rounded,
          title: "SECURE",
          desc: "End-to-end encryption",
          delay: 100,
        ),
        const SizedBox(height: 14),
        _buildFeatureTile(
          icon: Icons.code_rounded,
          title: "POWERFUL",
          desc: "Advanced tools & features",
          delay: 200,
        ),
      ],
    );
  }

  Widget _buildFeatureTile({
    required IconData icon,
    required String title,
    required String desc,
    required int delay,
  }) {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 400 + delay),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
        decoration: BoxDecoration(
          color: glassPrimary,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: primaryWhite.withOpacity(0.12)),
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: primaryWhite.withOpacity(0.95),
                boxShadow: [
                  BoxShadow(color: primaryWhite.withOpacity(0.3), blurRadius: 12),
                ],
              ),
              child: Icon(icon, color: darkRed, size: 20),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: primaryWhite,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    desc,
                    style: TextStyle(fontSize: 12, color: softGrey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== JOIN OUR COMMUNITY ====================
  Widget _buildCommunitySection() {
    return Column(
      children: [
        const Text(
          "JOIN OUR COMMUNITY",
          style: TextStyle(
            color: primaryWhite,
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildSocialButton(
              icon: FontAwesomeIcons.telegram,
              color: const Color(0xFF0088cc),
              url: "https://t.me/ThisDevZenn",
              delay: 0,
            ),
            const SizedBox(width: 18),
            _buildSocialButton(
              icon: FontAwesomeIcons.tiktok,
              color: primaryWhite,
              url: "https://tiktok.com/@thisdevzen",
              delay: 100,
            ),
            const SizedBox(width: 18),
            _buildSocialButton(
              icon: FontAwesomeIcons.github,
              color: primaryWhite,
              url: "https://github.com/Foryouthat",
              delay: 200,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required Color color,
    required String url,
    required int delay,
  }) {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 400 + delay),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.scale(scale: value, child: child),
        );
      },
      child: GestureDetector(
        onTap: () => _openUrl(url),
        child: Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: primaryWhite.withOpacity(0.95),
            border: Border.all(color: color.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.35), blurRadius: 14, spreadRadius: 1),
            ],
          ),
          child: FaIcon(icon, color: color == primaryWhite ? darkRed : color, size: 22),
        ),
      ),
    );
  }

  // ==================== FOOTER ====================
  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          width: 50,
          height: 2,
          decoration: BoxDecoration(
            gradient: redGradient,
            borderRadius: BorderRadius.circular(1),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          "© 2026 VOREX EXECUTOR - Created by zenn",
          style: TextStyle(
            color: softGrey.withOpacity(0.6),
            fontSize: 10,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }
}

// Custom Grid Painter for background
class _GridPainter extends CustomPainter {
  static const Color accentRed = Color(0xFFF44336);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;

    const gridSize = 30.0;

    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final accentPaint = Paint()
      ..color = accentRed.withOpacity(0.08)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint);
    }

    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint);
    }

    final dotPaint = Paint()
      ..color = accentRed.withOpacity(0.1)
      ..style = PaintingStyle.fill;

    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize) {
        canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
