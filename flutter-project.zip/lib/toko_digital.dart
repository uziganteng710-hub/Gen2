import 'package:flutter/material.dart';
import 'dart:math' as math;

// ─── Palette Eksotik ──────────────────────────────────────────────────────────
class _EksotikColors {
  static const bgDark      = Color(0xFF0A0508);
  static const surface     = Color(0xFF140A0E);
  static const card        = Color(0xFF1E0F16);
  static const cardInner   = Color(0xFF2A1420);
  
  // Merah darah
  static const redDark     = Color(0xFF8B0000);
  static const redFire     = Color(0xFFCC0000);
  static const redBlood    = Color(0xFFDC143C);
  static const redGlow     = Color(0xFFFF1744);
  static const redNeon     = Color(0xFFFF0040);
  
  // Biru gelap
  static const blueDark    = Color(0xFF0A1628);
  static const blueDeep    = Color(0xFF0D2847);
  static const blueMid     = Color(0xFF1A4F8A);
  static const blueLight   = Color(0xFF4A94E8);
  static const blueNeon    = Color(0xFF00BFFF);
  
  // Putih
  static const white       = Color(0xFFFFFFFF);
  static const whiteSmoke  = Color(0xFFF5F0F0);
  static const whiteGold   = Color(0xFFFFF8E7);
  static const whiteDim    = Color(0xFFCCCCCC);
  
  static const text        = Color(0xFFF5EEEE);
  static const textSub     = Color(0xFFA08090);
  static const textDim     = Color(0xFF5A3A4A);
  static const border      = Color(0xFF3A1A2A);
  static const borderLit   = Color(0xFF5A2A3A);
}

// ─── Main Page ───────────────────────────────────────────────────────────────
class TokoDigitalPage extends StatefulWidget {
  final String sessionKey;
  const TokoDigitalPage({super.key, required this.sessionKey});

  @override
  State<TokoDigitalPage> createState() => _TokoDigitalPageState();
}

class _TokoDigitalPageState extends State<TokoDigitalPage> with SingleTickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut)
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _EksotikColors.bgDark,
      body: Stack(
        children: [
          // Background efek
          _buildBgEffects(),
          SafeArea(
            child: CustomScrollView(
              slivers: [
                // Header
                SliverToBoxAdapter(child: _buildHeader()),
                // Harga Vorex
                SliverToBoxAdapter(child: _buildHargaVorex()),
                const SliverToBoxAdapter(child: SizedBox(height: 16)),
                // Server Cpanel
                SliverToBoxAdapter(child: _buildServerCpanel()),
                const SliverToBoxAdapter(child: SizedBox(height: 30)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBgEffects() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => CustomPaint(
        painter: _TokoBgPainter(_pulseCtrl.value),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_EksotikColors.redDark, _EksotikColors.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _EksotikColors.redFire.withOpacity(0.4), width: 1.5),
        boxShadow: [
          BoxShadow(color: _EksotikColors.redFire.withOpacity(0.3), blurRadius: 25, spreadRadius: 2),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: _EksotikColors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _EksotikColors.white.withOpacity(0.2)),
            ),
            child: const Icon(Icons.storefront_rounded, color: _EksotikColors.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'DIGITAL STORE TOOLS BY VOREX',
                  style: TextStyle(
                    color: _EksotikColors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                Text(
                  'OREXX ONE MARKETPLACE',
                  style: TextStyle(
                    color: _EksotikColors.whiteDim,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _EksotikColors.redFire.withOpacity(0.25),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _EksotikColors.redFire.withOpacity(0.3)),
            ),
            child: Text(
              '🔥 HOT',
              style: TextStyle(
                color: _EksotikColors.redNeon,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── HARGA VOREX ──────────────────────────────────────────────────────────
  Widget _buildHargaVorex() {
    return _buildGlowingCard(
      title: '🌐 𝘼𝙋𝙆 𝙏𝙀𝙍𝘽𝘼𝙍𝙐 1.7.0',
      subtitle: '𝙊𝙍𝙀𝙓𝙓 𝙊𝙉𝙀 ⸔⸕ 𝘾𝙍𝙀𝘼𝙏𝙀𝘿 𝘽𝙔 #𝙍𝙀𝙓𝙕𝙔𝙊𝙉𝙀044',
      accentColor: _EksotikColors.redFire,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Larangan
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _EksotikColors.redFire.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _EksotikColors.redFire.withOpacity(0.15)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('𝘓𝘈𝘙𝘈𝘕𝘎𝘈𝘕 𝘈𝘗𝘓𝘐𝘒𝘈𝘚𝘐 ↯',
                  style: TextStyle(color: _EksotikColors.redNeon, fontSize: 12, fontWeight: FontWeight.w700)
                ),
                SizedBox(height: 6),
                Text('• ʙᴀʀᴛᴇʀ ᴀɴᴄᴄᴏᴜɴᴛ', style: TextStyle(color: _EksotikColors.whiteDim, fontSize: 11)),
                Text('• ᴍᴇɴᴊᴀᴅɪᴋᴀɴ ʀᴏʟᴇ sᴇʙᴀɢᴀɪ ʙᴇɴᴇғɪᴛ', style: TextStyle(color: _EksotikColors.whiteDim, fontSize: 11)),
                Text('• ᴅɪʟᴀʀᴀɴɢ ʙᴀɴᴛɪɴɢ ʜᴀʀɢᴀ', style: TextStyle(color: _EksotikColors.whiteDim, fontSize: 11)),
                Text('• ᴍᴇᴍʙᴇʀ ᴅɪʟᴀʀᴀɴɢ ᴊᴜᴀʟ', style: TextStyle(color: _EksotikColors.whiteDim, fontSize: 11)),
                Text('• ᴅɪʟᴀʀᴀɴɢ ʙᴀɢɪ2', style: TextStyle(color: _EksotikColors.whiteDim, fontSize: 11)),
                SizedBox(height: 6),
                Text(
                  '(ɴᴏ ʀᴇғғ ᴀᴋᴜɴ ᴅɪ ʜᴀᴘᴜs ᴛᴀɴᴘᴀ ᴍᴜᴋᴀ ᴅᴀɴ ᴛᴀɴᴘᴀ ᴀᴍᴘᴜɴ, ᴅɪ ʙᴇʀɪ ʜᴜᴋᴜᴍᴀɴ) 🔇',
                  style: TextStyle(color: _EksotikColors.redFire, fontSize: 10, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Haters
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_EksotikColors.redDark, _EksotikColors.blueDeep],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Text(
              '𝘈𝘥𝘢 𝘏𝘢𝘵𝘵𝘦𝘳𝘴? 𝘉𝘦𝘳𝘵𝘪𝘯𝘥𝘢𝘬 𝘓𝘢𝘯𝘨𝘴𝘶𝘯𝘨 𝘈𝘫𝘢𝘬𝘪𝘯 𝘋𝘳𝘢𝘮𝘢, 𝘎𝘢 𝘉𝘦𝘳𝘢𝘯𝘪? 𝘉𝘶𝘬𝘢𝘯 𝘈𝘯𝘢𝘬 𝘖𝘳𝘦𝘹𝘹 𝘭𝘶 😂',
              style: TextStyle(color: _EksotikColors.white, fontSize: 11, fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(height: 12),
          // Update
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _EksotikColors.blueMid.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _EksotikColors.blueMid.withOpacity(0.2)),
            ),
            child: const Text(
              '📢 𝘜𝘗𝘋𝘈𝘛𝘌 𝘚𝘌𝘚𝘚𝘐𝘖𝘕 𝘈𝘎𝘜𝘚𝘛𝘜𝘚 17 𝘈𝘒𝘈𝘕 𝘜𝘗𝘋𝘈𝘛𝘌 𝘉𝘌𝘚𝘈𝘙 👋',
              style: TextStyle(color: _EksotikColors.blueLight, fontSize: 11, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(height: 16),
          // Daftar Harga
          const Text(
            '🔥 HARGA PROMO 🔥',
            style: TextStyle(
              color: _EksotikColors.redNeon,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 8),
          ..._buildPriceList([
            'ʙᴀsɪᴄ ᴛʀɪᴀʟ 1ʜ 2ᴋ | 2ʜ 3ᴋ',
            'ʙᴀsɪᴄ ᴘᴇʀᴍᴀ 5ᴋ | ʙᴀsɪᴄ ʙᴜʟᴀɴᴀɴ 3ᴋ',
            'ᴘᴇʀᴍᴀɴᴇɴ ᴀᴄᴄᴇs ✨ ᴠɪᴘ 7ᴋ',
            'ʀᴇsᴇʟʟᴇʀ 10ᴋ | ʀᴇsᴇʟʟᴇʀ-ᴘʀɪʙᴀᴅɪ 16ᴋ',
            'ᴅᴇᴠᴇʟᴏᴘᴇʀs 20ᴋ | ᴛᴀɴɢᴀɴ ᴋɪʀɪ 25ᴋ',
            'ᴛᴀɴɢᴀɴ ᴋᴀɴᴀɴ 30ᴋ | ᴄᴇᴏ-ᴜᴛᴀᴍᴀ 60ᴋ',
            'ᴏᴡɴᴇʀ 120ᴋ',
          ]),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _EksotikColors.redFire.withOpacity(0.05),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _EksotikColors.redFire.withOpacity(0.1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  '📝 ɴᴏᴛᴇ: ɴᴏ ɴᴇɢᴏ ʏᴀɴɢ ʙᴀsɪᴄ sᴀᴍᴘᴇ ʀᴇsᴇʟʟᴇʀ, ʏᴀɴɢ ʙᴏʟᴇʜ ɴᴇɢᴏ ᴅᴇᴠ sᴀᴍᴘᴇ ᴏᴡɴ',
                  style: TextStyle(color: _EksotikColors.whiteDim, fontSize: 10),
                ),
                Text(
                  '💰 ʜᴀʀɢᴀ ᴘʀᴏᴍᴏ sᴀᴍᴘᴀɪ ᴛᴀɴɢɢᴀʟ 25 ᴊᴜʟɪ ʏᴀ ᴊᴀᴅɪ ᴋᴇsᴇᴍᴘᴀᴛᴀɴ ɪɴɪ ʙᴏʀᴏɴɢ ᴜʏʏʏ 💜',
                  style: TextStyle(color: _EksotikColors.blueLight, fontSize: 10, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_EksotikColors.redDark, _EksotikColors.blueDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.shopping_cart_rounded, color: _EksotikColors.white, size: 16),
                SizedBox(width: 8),
                Text('GASS BUY @vorreexx', style: TextStyle(color: _EksotikColors.white, fontSize: 12, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'TAG ME : #OREXXZY044NOTFOUNDER',
            style: TextStyle(color: _EksotikColors.textSub, fontSize: 10),
          ),
          const SizedBox(height: 4),
          const Text(
            'ᴄᴏɴᴛᴀᴄᴛ ᴍᴇ @vorreexx',
            style: TextStyle(color: _EksotikColors.blueLight, fontSize: 11, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildPriceList(List<String> items) {
    return items.map((item) {
      final parts = item.split(' ');
      final isSpecial = parts.contains('ᴏᴡɴᴇʀ') || parts.contains('ᴄᴇᴏ');
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSpecial ? _EksotikColors.redFire.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: isSpecial ? Border.all(color: _EksotikColors.redFire.withOpacity(0.2)) : null,
        ),
        child: Row(
          children: [
            Icon(
              isSpecial ? Icons.star_rounded : Icons.circle_rounded,
              color: isSpecial ? _EksotikColors.redNeon : _EksotikColors.blueMid,
              size: 10,
            ),
            const SizedBox(width: 8),
            Text(
              item,
              style: TextStyle(
                color: isSpecial ? _EksotikColors.redNeon : _EksotikColors.text,
                fontSize: 12,
                fontWeight: isSpecial ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  // ─── SERVER CPANEL ──────────────────────────────────────────────────────────
  Widget _buildServerCpanel() {
    return _buildGlowingCard(
      title: 'SERVER CPANEL',
      subtitle: 'ROLE PANEL LEGAL BY JUNZ',
      accentColor: _EksotikColors.blueMid,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _EksotikColors.blueDeep.withOpacity(0.3),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _EksotikColors.blueMid.withOpacity(0.2)),
            ),
            child: Column(
              children: [
                ..._buildRoleList([
                  '👤 Reseller • 15K',
                  '💎 Premium • 16K',
                  '🛡️ PT • 17K',
                  '👑 Own • 19K',
                  '👊 Tangan Kanan • 20K',
                  '🗿 Ceo • 21K',
                  '⚡ Manager • 22K',
                  '🔥 All Role • 24K',
                  '💻 Developer • 25K',
                  '📺 Security • 27K',
                  '👤 CoFounder • 30K',
                  '👥 Founder • 32K',
                  '🛡️ Immortal • 34K',
                  '✨ King • 35K',
                  '🐉 Boss • 36K',
                  '🏆 Main Owner • 39K',
                ]),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _EksotikColors.redFire.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _EksotikColors.redFire.withOpacity(0.1)),
            ),
            child: const Text(
              'NO RUSAK HARGA AJG TUH TERUMATA @Vixsstore',
              style: TextStyle(color: _EksotikColors.redNeon, fontSize: 11, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            '🔥 KEUNTUNGAN:',
            style: TextStyle(color: _EksotikColors.redNeon, fontSize: 14, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          ..._buildKeuntunganList([
            '➠ UNLIMITED CREATE',
            '➠ FULL AKSES SESUAI ROLE',
            '➠ FAST PROCESS',
            '➠ SPEK RAM 54GB CORE 4',
            '➠ PANEL LEGAL ANTI MOKAD',
          ]),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_EksotikColors.blueDeep, _EksotikColors.redDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(30),
            ),
            child: const Text(
              '💬 BERMINAT? HUBUNGI @voreexx',
              style: TextStyle(color: _EksotikColors.white, fontSize: 12, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildRoleList(List<String> items) {
    return items.asMap().entries.map((entry) {
      final idx = entry.key;
      final item = entry.value;
      final isSpecial = idx >= 12;
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 1),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isSpecial ? _EksotikColors.redFire.withOpacity(0.05) : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          children: [
            Icon(
              isSpecial ? Icons.stars_rounded : Icons.circle_rounded,
              color: isSpecial ? _EksotikColors.redNeon : _EksotikColors.blueLight,
              size: 10,
            ),
            const SizedBox(width: 8),
            Text(
              item,
              style: TextStyle(
                color: isSpecial ? _EksotikColors.redNeon : _EksotikColors.text,
                fontSize: 12,
                fontWeight: isSpecial ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  List<Widget> _buildKeuntunganList(List<String> items) {
    return items.map((item) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            const Icon(Icons.check_circle_rounded, color: _EksotikColors.blueLight, size: 14),
            const SizedBox(width: 8),
            Text(
              item,
              style: const TextStyle(color: _EksotikColors.text, fontSize: 12),
            ),
          ],
        ),
      );
    }).toList();
  }

  // ─── Card Glowing ──────────────────────────────────────────────────────────
  Widget _buildGlowingCard({
    required String title,
    required String subtitle,
    required Color accentColor,
    required Widget child,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_EksotikColors.card, _EksotikColors.cardInner],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentColor.withOpacity(0.25), width: 1.2),
        boxShadow: [
          BoxShadow(color: accentColor.withOpacity(0.15), blurRadius: 30, spreadRadius: 2),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [accentColor.withOpacity(0.2), Colors.transparent],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              children: [
                Icon(Icons.flash_on_rounded, color: accentColor, size: 16),
                const SizedBox(width: 6),
                Text(
                  title,
                  style: TextStyle(
                    color: accentColor,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(color: _EksotikColors.textSub, fontSize: 10, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

// ─── Background Painter ──────────────────────────────────────────────────────
class _TokoBgPainter extends CustomPainter {
  final double pulse;
  _TokoBgPainter(this.pulse);

  @override
  void paint(Canvas canvas, Size size) {
    // Grid merah samar
    final gridPaint = Paint()
      ..color = _EksotikColors.redFire.withOpacity(0.05)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Glow merah
    final glow1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _EksotikColors.redFire.withOpacity(0.08 * pulse),
          Colors.transparent,
        ],
        radius: 0.7,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.3, size.height * 0.2),
        radius: size.width * 0.6,
      ));
    canvas.drawCircle(
      Offset(size.width * 0.3, size.height * 0.2),
      size.width * 0.6,
      glow1,
    );

    // Glow biru
    final glow2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _EksotikColors.blueMid.withOpacity(0.06 * pulse),
          Colors.transparent,
        ],
        radius: 0.5,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.8, size.height * 0.8),
        radius: size.width * 0.5,
      ));
    canvas.drawCircle(
      Offset(size.width * 0.8, size.height * 0.8),
      size.width * 0.5,
      glow2,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}