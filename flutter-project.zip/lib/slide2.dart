import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart'; // Import package video
import 'slide.dart'; 
import 'dashboard_page.dart'; 

class Slide2Page extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const Slide2Page({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<Slide2Page> createState() => _Slide2PageState();
}

class _Slide2PageState extends State<Slide2Page> {
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    // Inisialisasi video dari berkas aset lokal
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
        });
        _videoController.play(); // Putar otomatis saat masuk halaman
        _videoController.setLooping(true); // Putar terus-menerus
        _videoController.setVolume(0.0); // Di-mute secara default agar tidak mengagetkan user
      }).catchError((error) {
        debugPrint("Error loading video: $error");
      });
  }

  @override
  void dispose() {
    // Hancurkan controller dari memory saat berpindah halaman
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onHorizontalDragEnd: (details) {
          if (details.primaryVelocity != null) {
            if (details.primaryVelocity! < -300) {
              _navigateToDashboard(context);
            } else if (details.primaryVelocity! > 300) {
              _navigateToPreviousSlide(context);
            }
          }
        },
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF3A0000), 
                Color(0xFF1F0000), 
                Color(0xFF0D0D0D), 
                Color(0xFF521111), 
              ],
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                bottom: 50,
                left: -50,
                child: Container(
                  width: 250,
                  height: 250,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.redAccent.withOpacity(0.12),
                  ),
                ),
              ),

              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(height: 10),
                      
                      // ================= HEADER BRANDING =================
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.rocket_launch_rounded, color: Colors.redAccent, size: 26),
                          const SizedBox(width: 8),
                          Text(
                            "OREXBUGS HUB",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.white.withOpacity(0.95),
                              letterSpacing: 2.5,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),

                      // ================= KOLOM KOTAK VIDEO (DI ATAS INFO) =================
                      Container(
                        width: double.infinity,
                        height: 180, // Tinggi proporsional untuk kotak video banner
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.redAccent.withOpacity(0.5), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.redAccent.withOpacity(0.15),
                              blurRadius: 10,
                              spreadRadius: 1,
                            )
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: _isVideoInitialized
                              ? AspectRatio(
                                  aspectRatio: _videoController.value.aspectRatio,
                                  child: VideoPlayer(_videoController),
                                )
                              : const Center(
                                  child: CircularProgressIndicator(
                                    color: Colors.redAccent,
                                  ),
                                ),
                        ),
                      ),
                      
                      const SizedBox(height: 15),

                      // ================= KOLOM INFORMASI UPDATE BESAR =================
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.red.shade900.withOpacity(0.3),
                              const Color(0xFF1A0000).withOpacity(0.5),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.redAccent.withOpacity(0.4), width: 1.5),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const [
                                Icon(Icons.campaign_rounded, color: Colors.redAccent, size: 22),
                                SizedBox(width: 8),
                                Text(
                                  "PENGUMUMAN OREX",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    letterSpacing: 1.0,
                                  ),
                                ),
                              ],
                            ),
                            const Divider(color: Colors.white24, height: 16, thickness: 1),
                            Text(
                              "Informasi Orex Akan Update Besar 17 agustus ya Jadi Tungguin Dan Akan Ada Bagi2 akun gratis orex 😭",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.95),
                                fontSize: 13.5,
                                height: 1.5,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 15),

                      // ================= SUB TITLE BERITA =================
                      Row(
                        children: [
                          const Icon(Icons.newspaper_rounded, color: Colors.redAccent, size: 20),
                          const SizedBox(width: 8),
                          Text(
                            "PAGE INFORMASI INDONESIA",
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: Colors.white.withOpacity(0.85),
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      // ================= LIST INFORMASI & LINK INDONESIA =================
                      Expanded(
                        child: ListView(
                          physics: const BouncingScrollPhysics(),
                          children: [
                            _buildNewsCard(
                              title: "Detikcom - Informasi Berita Terkini & Terpopuler Indonesia",
                              url: "https://www.detik.com",
                              desc: "Pusat informasi berita terbaru, politik, hukum, ekonomi, cyber crime, dan teknologi terupdate di Indonesia.",
                            ),
                            _buildNewsCard(
                              title: "CNN Indonesia - Berita Harian Nasional & Internasional",
                              url: "https://www.cnnindonesia.com",
                              desc: "Menyajikan laporan mendalam seputar peristiwa nasional, teknologi gadget, hacks, ekonomi, dan berita viral tanah air.",
                            ),
                            _buildNewsCard(
                              title: "Kompas.com - Jernih Melihat Dunia",
                              url: "https://www.kompas.com",
                              desc: "Portal berita tepercaya Indonesia yang membahas isu sosial, edukasi digital, perkembangan infrastruktur, serta info terkini.",
                            ),
                            _buildNewsCard(
                              title: "Antara News - Kantor Berita Indonesia",
                              url: "https://www.antaranews.com",
                              desc: "Sumber informasi resmi dan terpercaya mengenai kabar terkini dari Sabang sampai Merauke secara berkala.",
                            ),
                          ],
                        ),
                      ),

                      // ================= NAVIGATION TRACK INDICATOR =================
                      const SizedBox(height: 10),
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.arrow_back_ios_new_rounded, color: Colors.redAccent.withOpacity(0.7), size: 16),
                              const SizedBox(width: 4),
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white.withOpacity(0.3),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                width: 20,
                                height: 8,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4),
                                  color: Colors.redAccent,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(Icons.arrow_forward_ios_rounded, color: Colors.redAccent.withOpacity(0.7), size: 16),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Swipe Kiri: Balik | Swipe Kanan: Dashboard",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.55),
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNewsCard({required String title, required String url, required String desc}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 13.5,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            desc,
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 12,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
            ),
            child: Text(
              url,
              style: const TextStyle(
                color: Colors.redAccent,
                fontSize: 11.5,
                fontWeight: FontWeight.bold,
                fontFamily: 'monospace',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToPreviousSlide(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => SlidePage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void _navigateToDashboard(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }
}
