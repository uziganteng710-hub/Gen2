import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'public_chat_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'control_panel.dart'; // ⬅️ Tambahkan import ControlPanelPage

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid; // ⬅️ Tambahkan UID

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid, // ⬅️ Tambahkan UID
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late String? uid; // ⬅️ Tambahkan UID

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();
  final GlobalKey<GlazeNavBarState> _navBarKey = GlobalKey();

  int onlineUsers = 0;
  int activeConnections = 0;

  // ===== QUICK ACTIONS =====
  int _quickActionsPage = 0;
  late PageController _quickActionsController;

  // ===== WEATHER =====
  String _weatherTemp = '--';
  String _weatherCity = 'Memuat...';
  String _weatherDesc = '';
  String _weatherHumidity = '--';
  String _weatherWind = '--';
  bool _weatherLoading = true;
  IconData _weatherIcon = Icons.wb_sunny_rounded;

  // ===== COLOR PALETTE =====
  static const Color bgMain = Color(0xFFCED4DA);
  static const Color bgSurface = Color(0xFFFFFFFF);
  static const Color bgCard = Color(0xFFF8F9FA);
  static const Color textMain = Colors.black87;
  static const Color textSub = Colors.black54;
  static const Color accentWhite = Color(0xFF4F46E5);
  static const Color borderLight = Color(0xFF4F46E5);
  static const Color borderGlass = Color(0xFF4F46E5);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid; // ⬅️ Simpan UID

    _quickActionsController = PageController(viewportFraction: 0.88);

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    _quickActionsController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/bug.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('wss://pterodactyl.cloud:4813'));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    }, onError: (e) => debugPrint("WS error: $e"));
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildNewsPage();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = InfoPage(sessionKey: sessionKey);
          break;
        case 3:
          _selectedPage = ToolsPage(
              sessionKey: sessionKey, userRole: role, listDoos: listDoos);
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
      else if (index == 5) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER CARD
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: bgSurface,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [accentWhite, accentWhite],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [BoxShadow(color: accentWhite.withOpacity(0.3), blurRadius: 12)],
                        ),
                        child: _profileImage != null
                            ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                            : Icon(Icons.person_rounded, color: Colors.white, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "$username",
                              style: TextStyle(
                                color: textMain,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            const SizedBox(height: 5),
                            Row(
                              children: [
                                _roleBadge(role.toUpperCase()),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    "· Exp: $expiredDate",
                                    style: TextStyle(color: textSub, fontSize: 11),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _buildStatChip(Icons.group_rounded, "$onlineUsers", "Online"),
                      const SizedBox(width: 24),
                      _buildStatChip(Icons.wifi_rounded, "$activeConnections", "Koneksi"),
                      const Spacer(),
                      _onlineBadge(),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // BERITA TERBARU
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 4,
                          height: 18,
                          decoration: BoxDecoration(
                            color: accentWhite,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "Berita Terbaru",
                          style: TextStyle(
                            color: textMain,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    Text(
                      "${newsList.length} artikel",
                      style: TextStyle(
                        color: textSub,
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (newsList.isNotEmpty)
                  SizedBox(
                    height: 200,
                    child: PageView.builder(
                      controller: PageController(viewportFraction: 0.88),
                      itemCount: newsList.length,
                      itemBuilder: (ctx, i) {
                        final item = newsList[i];
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: bgSurface,
                            border: Border.all(color: borderLight),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.06),
                                blurRadius: 14,
                                offset: const Offset(0, 6),
                              )
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                if (item['image'] != null && item['image'].toString().isNotEmpty)
                                  NewsMedia(url: item['image']),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.black.withOpacity(0.7),
                                        Colors.transparent,
                                      ],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 12,
                                  left: 12,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: accentWhite,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      "NEWS",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  bottom: 14,
                                  left: 14,
                                  right: 14,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item['title'] ?? '',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.bold,
                                          shadows: [
                                            Shadow(
                                              color: Colors.black.withOpacity(0.8),
                                              blurRadius: 8,
                                            )
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        item['desc'] ?? '',
                                        style: TextStyle(color: Colors.white70, fontSize: 11),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // JOIN CHANNEL + MANAGE SENDER
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Expanded(
                  child: _actionBannerCard(
                    icon: FontAwesomeIcons.telegram,
                    label: "Join Channel",
                    sub: "PARAPAM Project",
                    color: Colors.blue,
                    onTap: () => _openUrl("https://t.me/mizukiszn"),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 18),

          // QUICK ACTIONS CAROUSEL
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _sectionHeader(Icons.bolt_rounded, "Quick Actions"),
                    Text(
                      "New Features",
                      style: TextStyle(
                        color: textSub,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 120,
                child: PageView(
                  controller: _quickActionsController,
                  physics: const BouncingScrollPhysics(),
                  clipBehavior: Clip.none,
                  onPageChanged: (page) {
                    setState(() {
                      _quickActionsPage = page;
                    });
                  },
                  children: [
                    _quickActionCard(
                      icon: Icons.public_rounded,
                      label: "Global Chat",
                      sub: "Chat With All User",
                      gradient: [const Color(0xFF1A237E), const Color(0xFF3B5BDB)],
                      iconBg: const Color(0xFF3B5BDB),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PublicChatPage(
                            username: username, sessionKey: sessionKey, role: role
                          ),
                        ),
                      ),
                    ),
                    _quickActionCard(
                      icon: Icons.settings_remote_rounded,
                      label: "RAT Control Panel",
                      sub: "Remote Access Tools",
                      gradient: [const Color(0xFF6200EA), const Color(0xFFB388FF)],
                      iconBg: const Color(0xFF6200EA),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ControlPanelPage(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
            ],
          ),

          // DOT INDICATOR
          Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(2, (index) {
                final isActive = index == _quickActionsPage;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeInOut,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: isActive ? 20 : 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: isActive ? accentWhite : accentWhite.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
          ),

          const SizedBox(height: 16),

          // INFO & PENGUMUMAN
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(
              onTap: _showInfoDialog,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      accentWhite.withOpacity(0.05),
                      accentWhite.withOpacity(0.1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: accentWhite.withOpacity(0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: accentWhite.withOpacity(0.2),
                      blurRadius: 15,
                      offset: const Offset(0, 6),
                    )
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: accentWhite.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.info_outline, color: Colors.blue, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Info & Pengumuman",
                            style: TextStyle(
                              color: textMain,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "Klik untuk melihat info terbaru",
                            style: TextStyle(color: textSub, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, color: Colors.blue, size: 15),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // DIVIDER
          Center(
            child: Container(
              width: 60,
              height: 2,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, textSub, Colors.transparent],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // HUBUNGI KAMI
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(Icons.headset_mic_outlined, "HUBUNGI KAMI"),
                const SizedBox(height: 14),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Developer 01",
                  subtitle: "Telegram Developer 1",
                  color: const Color(0xFF25D366),
                  url: "https://t.me/mizukisnji",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Developer 2",
                  subtitle: "Fast response via Telegram",
                  color: const Color(0xFF0088cc),
                  url: "https://t.me/Xatanicvxii",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: Icons.telegram,
                  label: "Channel Information",
                  subtitle: "Update terbaru & pengumuman",
                  color: const Color(0xFF00BCD4),
                  url: "https://t.me/https://mizukiszn",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.tiktok,
                  label: "TikTok Developer",
                  subtitle: "content about the application",
                  color: textSub,
                  url: "https://www.tiktok.com/",
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ===== HELPER WIDGETS =====
  Widget _sectionHeader(IconData icon, String title) => Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: accentWhite.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: accentWhite, size: 16),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              color: textMain,
              fontSize: 15,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 0.5,
            ),
          ),
        ],
      );

  Widget _roleBadge(String text) {
    final lowerRole = text.toLowerCase();
    Color badgeColor;
    if (lowerRole == 'owner') {
      badgeColor = const Color(0xFFFFD700);
    } else if (lowerRole == 'moderator') {
      badgeColor = const Color(0xFF00E5FF);
    } else if (lowerRole == 'partner') {
      badgeColor = const Color(0xFF00E5FF);
    } else if (lowerRole == 'admin') {
      badgeColor = const Color(0xFFFF6D00);
    } else if (lowerRole == 'reseller' || lowerRole == 'seller') {
      badgeColor = const Color(0xFF4CAF50);
    } else {
      badgeColor = textSub;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: badgeColor.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: badgeColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: badgeColor,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _onlineBadge() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF00E676), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF00E676).withOpacity(0.25),
              blurRadius: 8,
            )
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 7,
              height: 7,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF00E676),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xFF00E676),
                    blurRadius: 6,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Text(
              "ONLINE",
              style: TextStyle(
                color: Color(0xFF00E676),
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                fontSize: 12,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      );

  Widget _buildStatChip(IconData icon, String value, String label) => Row(
        children: [
          Icon(icon, color: accentWhite, size: 17),
          const SizedBox(width: 5),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  color: textMain,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              Text(
                label,
                style: TextStyle(color: textSub, fontSize: 10),
              ),
            ],
          ),
        ],
      );

  Widget _actionBannerCard({
    required IconData icon,
    required String label,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.3)),
            boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 10)],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(icon, color: color, size: 16),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      sub,
                      style: TextStyle(color: color.withOpacity(0.7), fontSize: 10),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: color, size: 12),
            ],
          ),
        ),
      );

  Widget _quickActionCard({
    required IconData icon,
    required String label,
    required String sub,
    required List<Color> gradient,
    required Color iconBg,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: gradient.last.withOpacity(0.35),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -18,
              bottom: -18,
              child: Icon(
                icon,
                size: 90,
                color: Colors.white.withOpacity(0.07),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white.withOpacity(0.2)),
                    ),
                    child: Icon(icon, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          sub,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.18),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_forward_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactCard({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required String url,
  }) =>
      GestureDetector(
        onTap: () => _openUrl(url),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            color: bgSurface,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(0.5)),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: textMain,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(color: textSub, fontSize: 11),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: textSub, size: 13),
            ],
          ),
        ),
      );

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgSurface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: accentWhite),
            const SizedBox(width: 8),
            Text(
              "Info & Pengumuman",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
          ],
        ),
        content: Text(
          " Update Terbaru\n\n"
          "• Penambahan Tools Banyak Sekaligus\n"
          "• Memperbagus Dashboard\n"
          "• Dan Lain Lain!\n\n"
          "Terima kasih telah menggunakan Parapam!",
          style: TextStyle(color: textSub, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Tutup",
              style: TextStyle(color: accentWhite),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgSurface,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accentWhite.withOpacity(0.1), bgSurface],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [accentWhite, accentWhite]),
                      boxShadow: [BoxShadow(color: accentWhite.withOpacity(0.3), blurRadius: 12)],
                    ),
                    child: _profileImage != null
                        ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                        : Icon(Icons.person_rounded, color: Colors.white, size: 30),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          username,
                          style: TextStyle(
                            color: textMain,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 4),
                        _roleBadge(role.toUpperCase()),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                children: [
                  // ===== SIDEBAR MENU ITEMS =====
                  if (role == 'seller' || role == 'reseller')
                    _buildDrawerMenuItem(
                      icon: Icons.storefront_rounded,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == 'admin')
                    _buildDrawerMenuItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == 'partner')
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.handshake,
                      label: "Partner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  if (role == 'moderator')
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.userShield,
                      label: "Moderator Page",
                      onTap: () => _onSidebarTabSelected(4),
                    ),
                  if (role == 'owner')
                    _buildDrawerMenuItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(5),
                    ),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.lock_outline_rounded,
                    label: "Ganti Password",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildDrawerMenuItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final color = isLogout ? Colors.redAccent : textMain;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : bgSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isLogout ? Colors.red.withOpacity(0.3) : borderLight,
        ),
      ),
      child: ListTile(
        leading: Icon(icon, color: color, size: 20),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : textMain,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: textSub,
          size: 12,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          "Hai, $username",
          style: TextStyle(
            color: textMain,
            fontWeight: FontWeight.bold,
            fontSize: 18,
            fontFamily: 'Orbitron',
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: [
          IconButton(
            icon: Icon(Icons.headset_mic_outlined, color: textSub),
            tooltip: 'Customer Service',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ContactPage()),
            ),
          ),
          IconButton(
            icon: const Icon(FontAwesomeIcons.userCircle, color: Colors.black54),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                  uid: uid, // ⬅️ Kirim UID ke ProfilePage
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMain, bgSurface, bgMain],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _animation,
            child: _selectedPage,
          ),
        ),
      ),
      extendBody: true,
      bottomNavigationBar: Container(
        padding: EdgeInsets.zero,
        color: Colors.white.withOpacity(0.95),
        child: GlazeNavBar(
          key: _navBarKey,
          index: _bottomNavIndex,
          backgroundColor: Colors.transparent,
          items: [
            GlazeNavBarItem(
              child: Icon(
                Icons.home_rounded,
                color: _bottomNavIndex == 0 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'Home',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 0 ? accentWhite : textSub,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                FontAwesomeIcons.whatsapp,
                color: _bottomNavIndex == 1 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'WhatsApp',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 1 ? accentWhite : textSub,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.notifications_rounded,
                color: _bottomNavIndex == 2 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'Info',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 2 ? accentWhite : textSub,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.build_rounded,
                color: _bottomNavIndex == 3 ? accentWhite : textSub,
                size: 26,
              ),
              label: 'Tools',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 3 ? accentWhite : textSub,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
          onTap: (index) {
            _onBottomNavTapped(index);
          },
        ),
      ),
    );
  }
}

// NEWS MEDIA WIDGET
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFF4F46E5)),
      );
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.grey.shade200,
        child: const Icon(Icons.error, color: Colors.grey),
      ),
    );
  }
}