import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:image_picker/image_picker.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'public_chat.dart';

// ROLE PAGES
import 'ceo_utama_page.dart';
import 'tangan_kanan_page.dart';
import 'tangan_kiri_page.dart';
import 'developers_page.dart';
import 'pt_pribadi_page.dart';

// ─── BASE COLORS ─────────────────────────────────────────────────────────────
const Color kBgBase      = Color(0xFF080808);
const Color kCardBase    = Color(0xFF121212);
const Color kCardAltBase = Color(0xFF1A0D0D);
const Color kBorderBase  = Color(0xFF5A0F0F);
const Color kCyanBase    = Color(0xFFFF1744);
const Color kGreenBase   = Color(0xFFFF3D00);
const Color kPinkBase    = Color(0xFFFF0055);
const Color kOrangeBase  = Color(0xFFFF5722);
const Color kBlueBase    = Color(0xFFD50000);
const Color kPurpleBase  = Color(0xFFFF1744);
const Color kYellowBase  = Color(0xFFFF5252);
const Color kWhiteBase   = Colors.white;
const Color kWhite54Base = Colors.white54;
const Color kWhite24Base = Colors.white24;
const Color kAccentPurpleBase = Color(0xFFA855F7);
const Color kAccentPurpleDarkBase = Color(0xFF6D28D9);

// ─── Colors yang bisa diubah secara real-time ─────────────────────────────
late Color kBg, kCard, kCardAlt, kBorder, kCyan, kGreen, kPink, kOrange, kBlue, kPurple, kYellow, kWhite, kWhite54, kWhite24, kAccentPurple, kAccentPurpleDark;

// ─── Prayer Time Service ─────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── ANIMATED DOT ───────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ─── SPIDER WEB PATTERN PAINTER ────────────────────────────────────────────
class _SpiderWebPainter extends CustomPainter {
  final Color color;
  const _SpiderWebPainter({this.color = Colors.white24});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    final center = Offset(size.width * 0.9, size.height * 0.1);
    final maxRadius = size.longestSide * 1.2;

    const strands = 10;
    final angles = <double>[];
    for (int i = 0; i < strands; i++) {
      final angle = math.pi + (i * (math.pi * 0.5 / (strands - 1)));
      angles.add(angle);
    }

    for (final angle in angles) {
      final dx = center.dx + maxRadius * math.cos(angle);
      final dy = center.dy + maxRadius * math.sin(angle);
      canvas.drawLine(center, Offset(dx, dy), paint);
    }

    const rings = 6;
    for (int r = 1; r <= rings; r++) {
      final radius = maxRadius * (r / rings);
      final path = Path();
      for (int i = 0; i < angles.length; i++) {
        final dx = center.dx + radius * math.cos(angles[i]);
        final dy = center.dy + radius * math.sin(angles[i]);
        if (i == 0) path.moveTo(dx, dy);
        else path.lineTo(dx, dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SpiderWebPainter oldDelegate) => oldDelegate.color != color;
}

// ─── GRID PATTERN PAINTER ──────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({required this.gridColor, required this.lineColor, required this.spacing});
  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()..color = gridColor..strokeWidth = 0.8..style = PaintingStyle.stroke;
    final paintLines = Paint()..color = lineColor..strokeWidth = 0.4..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paintLines);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), paintLines);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── Dashboard Page ─────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;

  int _navIndex   = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  // ── Video Banner ──────────────────────────────────────────────────────
  VideoPlayerController? _videoCtrl;

  // ── Animation controllers ─────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;

  // News carousel
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  // Quick Actions carousel
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  // ── Location ──
  bool _locationLoading = false;
  bool _locationGranted = false;

  // ── Prayer times ──
  String _prayerCity = 'Surabaya';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  // ── Hadith ──
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  // ── BACKGROUND COSTUME ──────────────────────────────────────────────
  String _bgType = 'default';
  String _bgPath = '';
  VideoPlayerController? _bgVideoCtrl;

  // ── COLOR COSTUME ──────────────────────────────────────────────────
  Color _themeColor = kCyanBase;

  // ── INDONESIA CLOCK ────────────────────────────────────────────────
  String _selectedCity = 'Jakarta';
  String _currentTime = '--:--:--';
  Timer? _clockTimer;
  Map<String, String> _cityTimeZone = {
    'Jakarta': 'Asia/Jakarta',
    'Surabaya': 'Asia/Jakarta',
    'Medan': 'Asia/Jakarta',
    'Makassar': 'Asia/Makassar',
    'Jayapura': 'Asia/Jayapura',
  };

  // ── WEATHER ──────────────────────────────────────────────────────────
  String _weatherTemp = '--°C';
  String _weatherDesc = '...';
  IconData _weatherIcon = Icons.cloud;
  bool _weatherLoading = true;

  // ── SENDER ─────────────────────────────────────────────────────────
  int get _senderCount => listDoos.length;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _loadColorsAndBackground();

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _initAndroidId();
    _loadProfileImage();
    _initVideoBanner();
    _detectLocationAndFetchPrayer();
    _fetchRandomHadith();
    _startClock();
    _fetchWeather();
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _videoCtrl?.dispose();
    _bgVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }

  // ── Load saved colors & background ──────────────────────────────────
  Future<void> _loadColorsAndBackground() async {
    final prefs = await SharedPreferences.getInstance();
    int? colorVal = prefs.getInt('themeColor');
    if (colorVal != null) {
      setState(() {
        _themeColor = Color(colorVal);
        _applyThemeColors(_themeColor);
      });
    } else {
      setState(() {
        _applyThemeColors(kCyanBase);
      });
    }

    String? bgType = prefs.getString('bgType');
    String? bgPath = prefs.getString('bgPath');
    if (bgType != null && bgPath != null) {
      setState(() {
        _bgType = bgType;
        _bgPath = bgPath;
      });
      if (bgType == 'video') {
        _initBgVideo(bgPath);
      }
    }
  }

  void _applyThemeColors(Color base) {
    kBg = kBgBase;
    kCard = kCardBase;
    kCardAlt = kCardAltBase;
    kBorder = kBorderBase;
    kCyan = base;
    kGreen = base;
    kPink = base;
    kOrange = base;
    kBlue = base;
    kPurple = base;
    kYellow = base;
    kWhite = kWhiteBase;
    kWhite54 = kWhite54Base;
    kWhite24 = kWhite24Base;
    kAccentPurple = kAccentPurpleBase;
    kAccentPurpleDark = kAccentPurpleDarkBase;
  }

  void _initBgVideo(String url) {
    _bgVideoCtrl?.dispose();
    _bgVideoCtrl = VideoPlayerController.networkUrl(Uri.parse(url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _bgVideoCtrl?.setLooping(true);
        _bgVideoCtrl?.setVolume(0);
        _bgVideoCtrl?.play();
      }).catchError((e) {
        setState(() { _bgType = 'default'; });
      });
  }

  Widget _buildBackground() {
    if (_bgType == 'default') {
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0D1117), Color(0xFF0A0D14)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      );
    } else if (_bgType == 'image' && _bgPath.isNotEmpty) {
      if (_bgPath.startsWith('http')) {
        return Image.network(_bgPath, fit: BoxFit.cover);
      } else {
        return Image.file(File(_bgPath), fit: BoxFit.cover);
      }
    } else if (_bgType == 'url' && _bgPath.isNotEmpty) {
      return Image.network(_bgPath, fit: BoxFit.cover);
    } else if (_bgType == 'video' && _bgVideoCtrl != null && _bgVideoCtrl!.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _bgVideoCtrl!.value.size.width,
          height: _bgVideoCtrl!.value.size.height,
          child: VideoPlayer(_bgVideoCtrl!),
        ),
      );
    } else {
      return Container(color: kBg);
    }
  }

  // ── Video Banner ──────────────────────────────────────────────────────
  void _initVideoBanner() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/logo.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _videoCtrl?.setLooping(true);
        _videoCtrl?.setVolume(0);
        _videoCtrl?.play();
      }).catchError((e) {
        // jika video tidak ditemukan, abaikan
      });
  }

  // ── Clock ─────────────────────────────────────────────────────────────
  void _startClock() {
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
  }

  Future<void> _updateClock() async {
    if (_selectedCity.isEmpty) return;
    final timezone = _cityTimeZone[_selectedCity] ?? 'Asia/Jakarta';
    try {
      final response = await http.get(
        Uri.parse('http://worldtimeapi.org/api/timezone/$timezone'),
      ).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final datetime = data['datetime'];
        if (datetime != null) {
          final dt = DateTime.parse(datetime);
          final formatted = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}';
          if (mounted) setState(() => _currentTime = formatted);
          return;
        }
      }
    } catch (_) {}
    final now = DateTime.now();
    final formatted = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    if (mounted) setState(() => _currentTime = formatted);
  }

  void _showChangeCityClockDialog() {
    final cities = _cityTimeZone.keys.toList();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text('Pilih Kota', style: TextStyle(color: kWhite, fontFamily: 'Orbitron')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: cities.map((city) {
            return ListTile(
              title: Text(city, style: TextStyle(color: kWhite)),
              onTap: () {
                setState(() {
                  _selectedCity = city;
                });
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  // ── Weather ──────────────────────────────────────────────────────────
  Future<void> _fetchWeather() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);
    try {
      final res = await http.get(
        Uri.parse('https://wttr.in/Jakarta?format=%C+%t&lang=id')
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final parts = res.body.split(' ');
        final desc = parts.sublist(0, parts.length - 1).join(' ');
        final temp = parts.last;
        setState(() {
          _weatherDesc = desc;
          _weatherTemp = temp;
          _weatherLoading = false;
          if (desc.toLowerCase().contains('hujan')) {
            _weatherIcon = Icons.grain;
          } else if (desc.toLowerCase().contains('cerah')) {
            _weatherIcon = Icons.wb_sunny;
          } else if (desc.toLowerCase().contains('berawan')) {
            _weatherIcon = Icons.cloud;
          } else {
            _weatherIcon = Icons.cloud_queue;
          }
        });
      } else {
        setState(() => _weatherLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _weatherLoading = false);
    }
  }

  // ── Init helpers ──────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  String get _expiredLabel {
    final v = expiredDate.trim();
    if (v.isEmpty || v.toUpperCase().contains('PERMANENT')) return 'PERMANENT';
    return v.length > 10 ? v.substring(0, 10) : v;
  }

  void _connectWS() {
    final wsUrl = ApiConfig.baseUrl
        .replaceFirst('https://', 'wss://')
        .replaceFirst('http://', 'ws://');
    channel = WebSocketChannel.connect(Uri.parse(wsUrl));

    channel.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConns = data['activeConnections'] ?? 0;
        });
      }
      if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Session invalid');
      }
      if (data['type'] == 'forceLogout' && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Logged out');
      }
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  // ── Fetch Prayer Times ────────────────────────────────────────────────
  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Surabaya';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Surabaya';
        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });
        await _fetchPrayerTimes();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kGreen,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Surabaya';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: Colors.white54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: Icon(Icons.location_city_rounded, color: kGreen),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kGreen,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Fetch Hadith ──────────────────────────────────────────────────────
  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kCyan.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kCyan.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kCyan.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kCyan.withOpacity(0.2)),
                      child: Icon(Icons.menu_book_rounded, color: kCyan, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                        Text(grade, style: TextStyle(color: kCyan, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded, color: Colors.white54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF1A1F2E),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: Colors.white, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kCyan)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:', style: TextStyle(color: Colors.cyan, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF141824),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: Colors.white, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kCyan.withOpacity(0.5)),
                          color: kCyan.withOpacity(0.08),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.receipt_long_rounded, color: kCyan, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: TextStyle(color: kCyan, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: Colors.white)),
        content: Text(message, style: const TextStyle(color: Colors.white54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: Colors.cyan)),
          ),
        ],
      ),
    );
  }

  // ── Navigation ──────────────────────────────────────────────────────────
  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  void _onDrawerNavRole(String roleName) {
    Widget page;
    String cleanRole = roleName.toLowerCase().replaceAll('-', '_');
    switch (cleanRole) {
      case 'ceo_utama':
        page = CeoUtamaPage(sessionKey: sessionKey, username: username);
        break;
      case 'tangan_kanan':
        page = TanganKananPage(sessionKey: sessionKey, username: username);
        break;
      case 'tangan_kiri':
        page = TanganKiriPage(sessionKey: sessionKey, username: username);
        break;
      case 'pt_pribadi':
        page = PtPribadiPage(sessionKey: sessionKey, username: username);
        break;
      case 'developers':
        page = DevelopersPage(sessionKey: sessionKey, username: username);
        break;
      default:
        return;
    }
    Navigator.pop(context);
    Navigator.push(context, _slideRoute(page));
  }

  // ── Current Page ──────────────────────────────────────────────────────
  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return HomePage(
          username: username, password: password,
          listBug: listBug, role: role,
          expiredDate: expiredDate, sessionKey: sessionKey,
        );
      case 2:
        return InfoPage(sessionKey: sessionKey);
      case 3:
        return ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      case 0:
      default:
        return _buildHomePage();
    }
  }

  // ── HOME PAGE ───────────────────────────────────────────────────────────
  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10), // tambahan jarak agar video turun
            _buildVideoBanner(),
            const SizedBox(height: 12),
            _buildMainCard(),
            const SizedBox(height: 14),
            _buildSuratUcapan(), // SURAT UCAPAN baru
            const SizedBox(height: 14),
            _buildBeritaTerbaru(),
            const SizedBox(height: 16),
            _buildQuickActionsSection(),
            const SizedBox(height: 16),
            _buildToolsUpdateSection(),
            const SizedBox(height: 16),
            _buildJamIndonesia(),
            const SizedBox(height: 16),
            _buildPrayerSection(),
            const SizedBox(height: 16),
            _buildHadithSection(),
            const SizedBox(height: 16),
            _buildFooterCopyright(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // ── Video Banner ──────────────────────────────────────────────────────
  Widget _buildVideoBanner() {
    final ready = _videoCtrl != null && _videoCtrl!.value.isInitialized;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Container(
          height: 150,
          width: double.infinity,
          color: Colors.black,
          child: ready
              ? FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoCtrl!.value.size.width,
                    height: _videoCtrl!.value.size.height,
                    child: VideoPlayer(_videoCtrl!),
                  ),
                )
              : const Center(child: CircularProgressIndicator(color: Colors.orange)),
        ),
      ),
    );
  }

  // ── Main Card ──────────────────────────────────────────────────────
  Widget _buildMainCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          image: DecorationImage(
            image: AssetImage('assets/images/card.png'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.3), BlendMode.darken),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 10)),
          ],
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: CustomPaint(painter: _SpiderWebPainter(color: Colors.white10)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ScaleTransition(
                        scale: _pulseAnim,
                        child: Container(
                          width: 44, height: 44,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white.withOpacity(0.6), width: 2),
                            boxShadow: [BoxShadow(color: Colors.white.withOpacity(0.3), blurRadius: 12)],
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/logo.png',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: kCard,
                                child: Icon(Icons.security_rounded, color: Colors.white, size: 22),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'SUPERNOVA',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Row(
                              children: [
                                Text(username,
                                    style: const TextStyle(
                                        color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4),
                                    color: Colors.orange.withOpacity(0.3),
                                    border: Border.all(color: Colors.orange.withOpacity(0.5)),
                                  ),
                                  child: Text(role.toUpperCase(),
                                      style: const TextStyle(
                                          color: Colors.orange, fontSize: 8, fontWeight: FontWeight.bold)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.timer_outlined, color: Colors.green, size: 10),
                              SizedBox(width: 2),
                              Text('EXPIRES', style: TextStyle(color: Colors.white54, fontSize: 8)),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.green.withOpacity(0.6)),
                              color: Colors.green.withOpacity(0.15),
                            ),
                            child: Text(_expiredLabel,
                                style: const TextStyle(
                                    color: Colors.green, fontSize: 8, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildStatItem('Online Users', onlineUsers.toString(), Icons.people),
                      _buildStatItem('Sender', _senderCount.toString(), Icons.send),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildActionButton('GUIDE TERMUX', Icons.terminal, () {
                        _openUrl('https://example.com/termux');
                      }),
                      _buildActionButton('GUIDE VPS', Icons.cloud, () {
                        _openUrl('https://example.com/vps');
                      }),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Row(
          children: [
            Icon(icon, color: Colors.white70, size: 14),
            const SizedBox(width: 4),
            Text(value,
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
          ],
        ),
        Text(label,
            style: const TextStyle(color: Colors.white54, fontSize: 8)),
      ],
    );
  }

  Widget _buildActionButton(String label, IconData icon, VoidCallback onTap) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.3)),
            color: Colors.white.withOpacity(0.08),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 14),
              const SizedBox(width: 4),
              Text(label,
                  style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SURAT UCAPAN ────────────────────────────────────────────────────────
  Widget _buildSuratUcapan() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: GestureDetector(
        onTap: () => _showGreetingCardDialog(),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.deepOrange.withOpacity(0.3), Colors.red.withOpacity(0.2)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.orangeAccent.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(color: Colors.deepOrange.withOpacity(0.2), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.15),
                  border: Border.all(color: Colors.orangeAccent.withOpacity(0.6)),
                ),
                child: const Icon(Icons.card_giftcard_rounded, color: Colors.white, size: 22),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  '📩 SURAT UCAPAN - Klik untuk membuka!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  void _showGreetingCardDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF8A3D), Color(0xFFE0201B), Color(0xFFFFFFFF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          padding: const EdgeInsets.all(2),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.celebration_rounded, color: Colors.orange, size: 40),
                const SizedBox(height: 10),
                const Text(
                  'Merdeka Indonesiaaa! 🇮🇩',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Semoga Negara kita maju, berdaulat, dan makmur,'
                  ' sehingga kita tidak lagi merasakan penjajahan dan peperangan antar negara.\n'
                  'Semoga kita senantiasa dilindungi oleh ALLAH SWT.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.5),
                ),
                const SizedBox(height: 16),
                const Text(
                  '- Zenn -',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withOpacity(0.5)),
                    ),
                    child: const Text('Tutup', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Berita Terkini ──────────────────────────────────────────────────
  Widget _buildBeritaTerbaru() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.newspaper, color: Colors.orange, size: 18),
              const SizedBox(width: 6),
              const Text('BERITA TERKINI',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13,
                      fontFamily: 'Orbitron', letterSpacing: 0.5)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.orange.withOpacity(0.2),
                    border: Border.all(color: Colors.orange.withOpacity(0.3)),
                  ),
                  child: Text('${newsList.length}',
                      style: const TextStyle(color: Colors.orange, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 160,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 80,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: kCard,
                  border: Border.all(color: kBorder.withOpacity(0.4))),
              child: const Center(child: Text('Tidak ada berita', style: TextStyle(color: Colors.white54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: kCard,
        border: Border.all(color: kBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            child: Container(
              height: 90,
              width: double.infinity,
              color: kCardAlt,
              child: imgUrl.isNotEmpty
                  ? Image.network(imgUrl, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.image_not_supported, color: Colors.white54, size: 24)))
                  : const Center(child: Icon(Icons.article_rounded, color: Colors.white54, size: 24)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 6, 8, 4),
            child: Text(title,
                style: const TextStyle(
                  color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', height: 1.2),
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: Colors.white54, size: 10),
                const SizedBox(width: 3),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10 ? date.substring(0, 10) : date,
                        style: const TextStyle(color: Colors.white54, fontSize: 8)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Quick Actions ──────────────────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    final actions = [
      // Tambahan button WHATSAPP
      // ==================== QUICK ACTION DATA ====================
_QuickActionData(
  icon: FontAwesomeIcons.whatsapp,
  bgIcon: FontAwesomeIcons.whatsapp,
  title: 'Bug WhatsApp',
  subtitle: 'Kelola Bug WhatsApp',
  gradient: [Colors.grey.shade700, Colors.grey.shade900],
  onTap: () => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => HomePage(
      username: username,
      password: password,
      listBug: listBug,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
    )),
  ),
),
_QuickActionData(
  icon: FontAwesomeIcons.telegram,
  bgIcon: FontAwesomeIcons.telegram,
  title: 'Join Channel',
  subtitle: 'CHANNELS VOREX INFORMATION',
  gradient: [const Color(0xFF00B4D8), const Color(0xFF0077B6)],
  onTap: () => _openUrl('https://t.me/forlexstar'),
),
_QuickActionData(
  icon: FontAwesomeIcons.bookQuran,
  bgIcon: FontAwesomeIcons.bookQuran,
  title: 'Al Quran',
  subtitle: 'Baca Al-Quran',
  gradient: [const Color(0xFF7C4DFF), const Color(0xFF4A148C)],
  onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
),
_QuickActionData(
  icon: FontAwesomeIcons.tv,
  bgIcon: FontAwesomeIcons.tv,
  title: 'Anime',
  subtitle: 'Discover & Watch Anime',
  gradient: [const Color(0xFFFF6D00), const Color(0xFFE65100)],
  onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
),
// ==================== MANAGE SENDERS (BARU) ====================
_QuickActionData(
  icon: FontAwesomeIcons.usersGear,
  bgIcon: FontAwesomeIcons.usersGear,
  title: 'Manage Senders',
  subtitle: 'Kelola Sender Aktif',
  gradient: [
    const Color(0xFFFF1493).withOpacity(0.7), // Pink transparan
    const Color(0xFFFF69B4).withOpacity(0.5), // Pink muda transparan
  ],
  onTap: () => Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => BugSenderPage(
        username: username,
        password: password,
        sessionKey: sessionKey,
        role: role,
      ),
    ),
  ),
),
];
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 32, height: 32,
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.amber.withOpacity(0.2),
                  border: Border.all(color: Colors.amber.withOpacity(0.3)),
                ),
                child: const Icon(Icons.bolt_rounded, color: Colors.amber, size: 16),
              ),
              const SizedBox(width: 8),
              const Text('QUICK ACTIONS',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12,
                      fontFamily: 'Orbitron', letterSpacing: 0.5)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 130,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 16 : 5,
              height: 5,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                color: isActive ? Colors.amber : Colors.white24,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          border: Border.all(color: kAccentPurple.withOpacity(0.2), width: 1),
          boxShadow: [
            BoxShadow(
                color: action.gradient.first.withOpacity(0.3),
                blurRadius: 12, offset: const Offset(0, 4)),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -8, bottom: -8,
              child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.06), size: 60),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.15)),
                    child: Icon(action.icon, color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(action.title,
                            style: const TextStyle(
                                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                        Text(action.subtitle,
                            style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 9)),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 12),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Tools Update ──────────────────────────────────────────────────────
  Widget _buildToolsUpdateSection() {
    final tools = [
      {'icon': Icons.settings_ethernet, 'label': 'NETWORK DE FULL', 'color': Colors.blue},
      {'icon': Icons.color_lens, 'label': 'COLLORING DASHBOARD COSTUME', 'color': Colors.purple},
      {'icon': Icons.image, 'label': 'COSTUME DASHBOARD BACKGROUND', 'color': Colors.orange},
      {'icon': Icons.download, 'label': 'DOWNLOAD', 'color': Colors.green},
      {'icon': Icons.movie, 'label': 'ANIME', 'color': Colors.red},
      {'icon': Icons.build, 'label': 'EXTRA TOOLS', 'color': Colors.teal},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.build, color: Colors.orange, size: 18),
              const SizedBox(width: 6),
              const Text('TOOLS UPDATE',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12,
                      fontFamily: 'Orbitron', letterSpacing: 0.5)),
            ],
          ),
          const SizedBox(height: 8),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1.0,
            ),
            itemCount: tools.length,
            itemBuilder: (ctx, i) {
              final tool = tools[i];
              return _buildToolButton(
                icon: tool['icon'] as IconData,
                label: tool['label'] as String,
                color: tool['color'] as Color,
                onTap: () {
                  if (tool['label'] == 'COLLORING DASHBOARD COSTUME') {
                    _showColorPickerDialog();
                  } else if (tool['label'] == 'COSTUME DASHBOARD BACKGROUND') {
                    _showBackgroundPickerDialog();
                  } else if (tool['label'] == 'DOWNLOAD') {
                    _openUrl('https://example.com/download');
                  } else if (tool['label'] == 'ANIME') {
                    Navigator.push(context, _slideRoute(HomeAnimePage()));
                  } else if (tool['label'] == 'EXTRA TOOLS') {
                    Navigator.push(context, _slideRoute(ToolsPage(
                      sessionKey: sessionKey,
                      userRole: role,
                      listDoos: listDoos,
                    )));
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${tool['label']} akan segera hadir')),
                    );
                  }
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildToolButton({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.15), color.withOpacity(0.03)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Jam Indonesia ──────────────────────────────────────────────────────
  Widget _buildJamIndonesia() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.25),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Icon(Icons.access_time_rounded, color: Colors.amber, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('JAM INDONESIA',
                            style: TextStyle(
                                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 10,
                                fontFamily: 'Orbitron', letterSpacing: 0.3)),
                        Row(
                          children: [
                            Text(_currentTime,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron')),
                            const SizedBox(width: 6),
                            GestureDetector(
                              onTap: _showChangeCityClockDialog,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.white.withOpacity(0.08),
                                  border: Border.all(color: Colors.white.withOpacity(0.15)),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.location_city_rounded, color: Colors.amber, size: 10),
                                    const SizedBox(width: 2),
                                    Text(_selectedCity,
                                        style: const TextStyle(color: Colors.white70, fontSize: 9)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.circle, color: Colors.green, size: 6),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Prayer Section ──────────────────────────────────────────────────────
  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF5B4FD4),
      const Color(0xFFFF9800),
      const Color(0xFFFF5722),
      const Color(0xFF1E88E5),
      const Color(0xFF1565C0),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: kGreen.withOpacity(0.15),
                    border: Border.all(color: kGreen.withOpacity(0.3)),
                  ),
                  child: Center(child: Icon(Icons.mosque, color: kGreen, size: 18)),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('JADWAL SHOLAT',
                          style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11,
                            fontFamily: 'Orbitron', letterSpacing: 0.3)),
                      Text(_prayerCity,
                          style: const TextStyle(color: Colors.white54, fontSize: 9)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 28, height: 28,
                    margin: const EdgeInsets.only(right: 4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted ? kGreen.withOpacity(0.15) : Colors.white24.withOpacity(0.1),
                      border: Border.all(
                        color: _locationGranted ? kGreen.withOpacity(0.5) : Colors.white54.withOpacity(0.2),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(4),
                            child: CircularProgressIndicator(color: Colors.green, strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted ? Icons.my_location_rounded : Icons.location_searching_rounded,
                            color: _locationGranted ? kGreen : Colors.white54,
                            size: 14,
                          ),
                  ),
                ),
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: kGreen,
                    ),
                    child: const Text('GANTI',
                        style: TextStyle(
                            color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kGreen.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: _AnimatedDot(color: Colors.orange, size: 6),
                    ),
                    const SizedBox(width: 6),
                    Text('Menuju $_nextPrayerLabel : $_nextPrayerTime',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600,
                            fontFamily: 'Orbitron')),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: kGreen.withOpacity(0.3)),
                      ),
                      child: const Text('TRANZ',
                          style: TextStyle(color: Colors.green, fontSize: 7, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 8),
            if (_prayerLoading)
              const Center(child: CircularProgressIndicator(color: Colors.green, strokeWidth: 2))
            else
              SizedBox(
                height: 80,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key   = prayerKeys[i];
                    final time  = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon  = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(right: 6, bottom: isNext ? 0 : 4, top: isNext ? 0 : 4),
                      width: 68,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: color,
                        boxShadow: [
                          BoxShadow(
                              color: color.withOpacity(isNext ? 0.5 : 0.2),
                              blurRadius: isNext ? 10 : 4, offset: const Offset(0, 3))
                        ],
                        border: isNext
                            ? Border.all(color: Colors.white.withOpacity(0.4), width: 1.2)
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: Colors.white, size: 14),
                            const SizedBox(height: 2),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 6,
                                    fontWeight: FontWeight.bold, letterSpacing: 0.3)),
                            const SizedBox(height: 2),
                            Text(time,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 11,
                                    fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── Hadith Section ──────────────────────────────────────────────────────
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 140,
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder.withOpacity(0.4)),
          ),
          child: const Center(child: CircularProgressIndicator(color: Colors.cyan, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kCard, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: kCyan.withOpacity(0.15)),
                  child: Center(child: Icon(Icons.menu_book_rounded, color: kCyan, size: 18)),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('HADITH OF THE DAY',
                        style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11,
                          fontFamily: 'Orbitron', letterSpacing: 0.3)),
                    Text('$grade · Tap card',
                        style: const TextStyle(color: Colors.white54, fontSize: 8)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color(0xFF1A1F2E),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.8)),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10), color: const Color(0xFF141824)),
                    child: Text(indo,
                        style: const TextStyle(
                          color: Colors.white54, fontSize: 10, fontStyle: FontStyle.italic, height: 1.5),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: kCyan.withOpacity(0.3)),
                    color: kCyan.withOpacity(0.05),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.receipt_long_rounded, color: kCyan, size: 10),
                    const SizedBox(width: 3),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: TextStyle(
                            color: kCyan, fontSize: 8, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: Colors.white54.withOpacity(0.15)),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.touch_app_rounded, color: Colors.white54, size: 10),
                      SizedBox(width: 2),
                      Text('Refresh', style: TextStyle(color: Colors.white54, fontSize: 8)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Footer ──────────────────────────────────────────────────────────────
  Widget _buildFooterCopyright() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Center(
        child: Text(
          '© 2027 Vorexx ↤ Execution New!',
          style: TextStyle(
            color: Colors.white.withOpacity(0.3),
            fontSize: 9,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }

  // ─── DIALOGS FOR BACKGROUND & COLOR ──────────────────────────────────
  void _showColorPickerDialog() {
    // Lebih banyak warna dan desain geser horizontal
    final colors = [
      Colors.red,
      Colors.orange,
      Colors.amber,
      Colors.green,
      Colors.teal,
      Colors.blue,
      Colors.purple,
      Colors.pink,
      Colors.cyan,
      Colors.indigo,
      Colors.lime,
      Colors.deepOrange,
      Colors.brown,
      Colors.grey,
    ];
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Pilih Warna Tema', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        content: SizedBox(
          height: 120,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: colors.map((c) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _themeColor = c;
                      _applyThemeColors(c);
                      _saveColor(c);
                    });
                    Navigator.pop(context);
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: c,
                      border: Border.all(
                        color: _themeColor == c ? Colors.white : Colors.transparent,
                        width: 3,
                      ),
                      boxShadow: [
                        BoxShadow(color: c.withOpacity(0.5), blurRadius: 12),
                      ],
                    ),
                    child: _themeColor == c
                        ? const Icon(Icons.check, color: Colors.white, size: 24)
                        : null,
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup', style: TextStyle(color: Colors.white54)),
          ),
        ],
      ),
    );
  }

  Future<void> _saveColor(Color c) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('themeColor', c.value);
  }

  void _showBackgroundPickerDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Costume Background', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.image, color: Colors.orange),
              title: const Text('Pilih dari Galeri', style: TextStyle(color: Colors.white)),
              onTap: () async {
                final picker = ImagePicker();
                final picked = await picker.pickImage(source: ImageSource.gallery);
                if (picked != null) {
                  final path = picked.path;
                  setState(() {
                    _bgType = 'image';
                    _bgPath = path;
                  });
                  _saveBg('image', path);
                  Navigator.pop(context);
                }
              },
            ),
            ListTile(
              leading: Icon(Icons.link, color: Colors.blue),
              title: const Text('Masukkan URL Gambar', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _showUrlInputDialog();
              },
            ),
            ListTile(
              leading: Icon(Icons.video_library, color: Colors.red),
              title: const Text('Video Background', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _showVideoInputDialog();
              },
            ),
            ListTile(
              leading: Icon(Icons.restore, color: Colors.grey),
              title: const Text('Default (Hitam)', style: TextStyle(color: Colors.white)),
              onTap: () {
                setState(() {
                  _bgType = 'default';
                  _bgPath = '';
                  _bgVideoCtrl?.dispose();
                  _bgVideoCtrl = null;
                });
                _saveBg('default', '');
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showUrlInputDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('URL Gambar', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'https://example.com/image.jpg',
            hintStyle: TextStyle(color: Colors.white54),
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () {
              final url = ctrl.text.trim();
              if (url.isNotEmpty) {
                setState(() {
                  _bgType = 'url';
                  _bgPath = url;
                });
                _saveBg('url', url);
                Navigator.pop(context);
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showVideoInputDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('URL Video', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'https://example.com/video.mp4',
            hintStyle: TextStyle(color: Colors.white54),
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () {
              final url = ctrl.text.trim();
              if (url.isNotEmpty) {
                setState(() {
                  _bgType = 'video';
                  _bgPath = url;
                  _initBgVideo(url);
                });
                _saveBg('video', url);
                Navigator.pop(context);
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveBg(String type, String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('bgType', type);
    await prefs.setString('bgPath', path);
  }

  // ─── BOTTOM DRAWER ──────────────────────────────────────────────────────
  void _openBottomDrawer() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: const BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 8, bottom: 12),
              width: 32,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundImage: _profileImage != null
                            ? FileImage(_profileImage!)
                            : const AssetImage('assets/images/logo.png') as ImageProvider,
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(username,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                          Text(role.toUpperCase(),
                              style: TextStyle(color: kCyan, fontSize: 10, letterSpacing: 0.5)),
                        ],
                      ),
                    ],
                  ),
                  const Divider(color: Colors.white24, height: 16),
                  _buildBubbleMenuItem(
                    icon: Icons.palette,
                    label: 'Background Costume',
                    onTap: () {
                      Navigator.pop(context);
                      _showBackgroundPickerDialog();
                    },
                    color: Colors.orange,
                  ),
                  _buildBubbleMenuItem(
                    icon: Icons.color_lens,
                    label: 'Collor Dashboard Costume',
                    onTap: () {
                      Navigator.pop(context);
                      _showColorPickerDialog();
                    },
                    color: Colors.purple,
                  ),
                  if (role.toLowerCase() == 'reseller')
                    _buildBubbleMenuItem(
                      icon: Icons.storefront,
                      label: 'Seller Page',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNav(1);
                      },
                      color: Colors.teal,
                    ),
                  if (role.toLowerCase() == 'admin')
                    _buildBubbleMenuItem(
                      icon: Icons.admin_panel_settings,
                      label: 'Admin Page',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNav(2);
                      },
                      color: Colors.blue,
                    ),
                  if (role.toLowerCase() == 'owner')
                    _buildBubbleMenuItem(
                      icon: Icons.workspace_premium,
                      label: 'Owner Page',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNav(3);
                      },
                      color: Colors.amber,
                    ),
                  if (role.toLowerCase() == 'ceo_utama' || role.toLowerCase() == 'owner')
                    _buildBubbleMenuItem(
                      icon: Icons.celebration,
                      label: 'CEO-UTAMA',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNavRole('ceo_utama');
                      },
                      color: Colors.amber,
                    ),
                  if (role.toLowerCase() == 'tangan_kanan' || role.toLowerCase() == 'ceo_utama' || role.toLowerCase() == 'owner')
                    _buildBubbleMenuItem(
                      icon: Icons.handshake,
                      label: 'TANGAN-KANAN',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNavRole('tangan_kanan');
                      },
                      color: Colors.lightGreen,
                    ),
                  if (role.toLowerCase() == 'tangan_kiri' || role.toLowerCase() == 'ceo_utama' || role.toLowerCase() == 'owner')
                    _buildBubbleMenuItem(
                      icon: Icons.handshake_outlined,
                      label: 'TANGAN-KIRI',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNavRole('tangan_kiri');
                      },
                      color: Colors.green,
                    ),
                  if (role.toLowerCase() == 'pt_pribadi' || role.toLowerCase() == 'ceo_utama' || role.toLowerCase() == 'owner')
                    _buildBubbleMenuItem(
                      icon: Icons.business_center,
                      label: 'PT-PRIBADI',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNavRole('pt_pribadi');
                      },
                      color: Colors.deepPurple,
                    ),
                  if (role.toLowerCase() == 'developers' || role.toLowerCase() == 'ceo_utama' || role.toLowerCase() == 'owner')
                    _buildBubbleMenuItem(
                      icon: Icons.code,
                      label: 'DEVELOPERS',
                      onTap: () {
                        Navigator.pop(context);
                        _onDrawerNavRole('developers');
                      },
                      color: Colors.cyan,
                    ),
                  _buildBubbleMenuItem(
                    icon: Icons.history,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role)));
                    },
                    color: Colors.indigo,
                  ),
                  _buildBubbleMenuItem(
                    icon: Icons.lock_outline,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                    color: Colors.redAccent,
                  ),
                  _buildBubbleMenuItem(
                    icon: Icons.logout,
                    label: 'Keluar',
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                    color: Colors.red,
                    isLogout: true,
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBubbleMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
    bool isLogout = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  color.withOpacity(0.15),
                  color.withOpacity(0.03),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isLogout ? Colors.red.withOpacity(0.4) : color.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: isLogout ? Colors.red : color, size: 18),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: isLogout ? Colors.red : Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(Icons.arrow_forward_ios_rounded, color: Colors.white24, size: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── BUILD ───────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    _applyThemeColors(_themeColor);

    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          _buildBackground(),
          CustomPaint(
            painter: _GridPatternPainter(
              gridColor: kCyan.withOpacity(0.03),
              lineColor: kPink.withOpacity(0.01),
              spacing: 30,
            ),
            size: Size.infinite,
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) => FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ─── APP BAR ─────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.menu, color: Colors.white, size: 24),
        onPressed: _openBottomDrawer,
        splashRadius: 18,
        splashColor: Colors.orange.withOpacity(0.2),
      ),
      title: ShaderMask(
        shaderCallback: (bounds) => const LinearGradient(
          colors: [Colors.orange, Colors.red, Colors.white],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ).createShader(bounds),
        child: const Text(
          'SUPERNOVA',
          style: TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 0.4,
          ),
        ),
      ),
      actions: [
        GestureDetector(
          onTap: _fetchWeather,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.orange.withOpacity(0.2)),
              color: Colors.black.withOpacity(0.2),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_weatherLoading)
                  const SizedBox(
                    width: 14, height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.orange),
                  )
                else
                  Row(
                    children: [
                      Icon(_weatherIcon, color: Colors.orange, size: 14),
                      const SizedBox(width: 2),
                      Text(_weatherTemp, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                    ],
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 4),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )),
          ),
          child: Container(
            width: 28, height: 28,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.orange.withOpacity(0.4), width: 1.2),
              color: Colors.black.withOpacity(0.2),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(FontAwesomeIcons.userAstronaut, color: Colors.orange, size: 12),
            ),
          ),
        ),
        const SizedBox(width: 6),
      ],
    );
  }

  // ─── BOTTOM NAV ──────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.home_rounded, label: 'Beranda'),
      _NavItem(icon: Icons.menu_book_rounded, label: 'Menu'),
      _NavItem(icon: Icons.build_rounded, label: 'Info'),
      _NavItem(icon: Icons.settings_rounded, label: 'Change pw'),
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C1E),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: SizedBox(
        height: 48,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (i) {
            final isActive = _navIndex == i;
            return GestureDetector(
              onTap: () {
                if (i == 1) {
                  _openBottomDrawer();
                } else if (i == 3) {
                  Navigator.push(
                    context,
                    _slideRoute(ProfilePage(
                      username: username, password: password,
                      role: role, expiredDate: expiredDate, sessionKey: sessionKey,
                    )),
                  );
                } else {
                  _onNavTap(i);
                }
              },
              child: SizedBox(
                width: 44,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (isActive)
                      Container(
                        width: 16,
                        height: 2,
                        margin: const EdgeInsets.only(bottom: 2),
                        decoration: BoxDecoration(
                          color: _themeColor,
                          borderRadius: BorderRadius.circular(1),
                        ),
                      ),
                    Icon(
                      items[i].icon,
                      color: isActive ? _themeColor : Colors.white54,
                      size: 18,
                    ),
                    const SizedBox(height: 1),
                    Text(
                      items[i].label,
                      style: TextStyle(
                        color: isActive ? _themeColor : Colors.white54,
                        fontSize: 8,
                        fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

// ─── Quick Action Data ──────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// ─── Nav Item ──────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ─── Slide Route ────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 280),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

// ─── NewsMedia ──────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: Colors.cyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: Colors.white24)),
    );
  }
}