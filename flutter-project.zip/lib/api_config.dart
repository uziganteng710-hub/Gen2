class ApiConfig {
  static const String baseUrl = "http://host.asta-official.my.id:9471";
}