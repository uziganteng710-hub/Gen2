// ceo_utama_page.dart
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

class CeoUtamaPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const CeoUtamaPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<CeoUtamaPage> createState() => _CeoUtamaPageState();
}

class _CeoUtamaPageState extends State<CeoUtamaPage>
    with AutomaticKeepAliveClientMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['CEO_UTAMA', 'TANGAN_KANAN', 'TANGAN_KIRI', 'DEVELOPERS', 'PT_PRIBADI', 'ADMIN', 'RESELLER', 'VIP', 'MEMBER'];
  String selectedRole = 'MEMBER';

  int currentPage = 1;
  final int itemsPerPage = 15;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'MEMBER';
  bool isLoading = false;
  bool isInitialLoad = true;
  bool isDeleting = false;
  bool isCreating = false;
  bool isEditing = false;

  List<dynamic> _cachedUserList = [];
  int _cacheTimestamp = 0;
  static const int _cacheDuration = 60000;

  final Color bgDark = const Color(0xFF1A1400);
  final Color primaryBlue = const Color(0xFF8B6914);
  final Color accentPurple = const Color(0xFFFFD700);
  final Color accentPink = const Color(0xFFFFA000);
  final Color deepOcean = const Color(0xFF2D2100);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);
  final Color successGreen = const Color(0xFF2ECC71);
  final Color warningOrange = const Color(0xFFFF9F43);
  final Color dangerRed = const Color(0xFFEF4444);

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  // ---------- ROLE HELPERS (icon & warna per role -> "full icon full colloring") ----------

  String _roleLabel(String role) {
    final resellerIndex = roleOptions.indexOf('RESELLER');
    final roleIndex = roleOptions.indexOf(role);
    if (resellerIndex == -1 || roleIndex == -1) return '';
    if (roleIndex < resellerIndex) {
      return ' (PERMANEN)';
    } else if (role == 'VIP') {
      return ' (MAX 50H)';
    } else if (roleIndex > resellerIndex) {
      return ' (MAX 30H)';
    }
    return '';
  }

  IconData _roleIcon(String role) {
    // Normalisasi: data dari server kadang pakai "-" (ceo-utama) kadang "_" (CEO_UTAMA)
    switch (role.toString().toUpperCase().replaceAll('-', '_')) {
      case 'CEO_UTAMA':
        return FontAwesomeIcons.crown;
      case 'TANGAN_KANAN':
        return FontAwesomeIcons.handshake;
      case 'TANGAN_KIRI':
        return FontAwesomeIcons.handshakeSimple;
      case 'PT_PRIBADI':
        return FontAwesomeIcons.building;
      case 'DEVELOPERS':
        return FontAwesomeIcons.code;
      case 'ADMIN':
        return FontAwesomeIcons.userShield;
      case 'RESELLER':
        return FontAwesomeIcons.store;
      case 'VIP':
        return FontAwesomeIcons.gem;
      case 'OWNER':
        return FontAwesomeIcons.certificate;
      default:
        return FontAwesomeIcons.user;
    }
  }

  Color _roleColor(String role) {
    switch (role.toString().toUpperCase().replaceAll('-', '_')) {
      case 'CEO_UTAMA':
        return const Color(0xFFFFD700);
      case 'TANGAN_KANAN':
        return const Color(0xFF00D9FF);
      case 'TANGAN_KIRI':
        return const Color(0xFF00FFA3);
      case 'PT_PRIBADI':
        return const Color(0xFFFF8C42);
      case 'DEVELOPERS':
        return const Color(0xFFFFD700);
      case 'ADMIN':
        return const Color(0xFFFFA000);
      case 'RESELLER':
        return const Color(0xFFFF8C42);
      case 'VIP':
        return const Color(0xFFFFC947);
      case 'OWNER':
        return const Color(0xFF4C6EF5);
      default:
        return const Color(0xFF60A5FA);
    }
  }

  // ---------- NETWORK ----------

  Future<void> _fetchUsers({bool forceRefresh = false}) async {
    final now = DateTime.now().millisecondsSinceEpoch;

    if (!forceRefresh &&
        _cachedUserList.isNotEmpty &&
        now - _cacheTimestamp < _cacheDuration) {
      fullUserList = _cachedUserList;
      _filterAndPaginate();
      if (mounted) setState(() => isInitialLoad = false);
      return;
    }

    if (mounted) setState(() => isLoading = true);
    try {
      http.Response res;
      try {
        res = await http
            .get(Uri.parse(
                'http://host.asta-official.my.id:9471/listUsers?key=$sessionKey'))
            .timeout(const Duration(seconds: 15));
      } on TimeoutException {
        // Retry sekali lagi sebelum menyerah, siapa tahu cuma lemot sesaat.
        res = await http
            .get(Uri.parse(
                'http://host.asta-official.my.id:9471/listUsers?key=$sessionKey'))
            .timeout(const Duration(seconds: 15));
      }

      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        _cachedUserList = data['users'] ?? [];
        _cacheTimestamp = now;
        fullUserList = _cachedUserList;
        _filterAndPaginate();
      } else {
        _alert("Info", data['message']?.toString() ?? 'Gagal memuat user.');
      }
    } on TimeoutException {
      if (_cachedUserList.isNotEmpty) {
        fullUserList = _cachedUserList;
        _filterAndPaginate();
        _alert("Info", "Server lambat merespons, menampilkan data cache.");
      } else {
        _alert("Error", "Koneksi ke server timeout. Coba lagi.");
      }
    } on SocketException {
      if (_cachedUserList.isNotEmpty) {
        fullUserList = _cachedUserList;
        _filterAndPaginate();
        _alert("Info", "Tidak ada koneksi internet, menampilkan data cache.");
      } else {
        _alert("Error", "Tidak ada koneksi internet.");
      }
    } on FormatException {
      _alert("Error", "Respon server tidak valid.");
    } catch (e) {
      if (_cachedUserList.isNotEmpty) {
        fullUserList = _cachedUserList;
        _filterAndPaginate();
        _alert("Info", "Menggunakan data cache.");
      } else {
        _alert("Error", "Gagal terhubung ke server.");
      }
    }
    if (mounted) {
      setState(() {
        isLoading = false;
        isInitialLoad = false;
      });
    }
  }

  void _filterAndPaginate() {
    if (!mounted) return;
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'].toString().toUpperCase() == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    if (filteredList.isEmpty) return [];
    final start = (currentPage - 1) * itemsPerPage;
    if (start >= filteredList.length) return [];
    final end = start + itemsPerPage;
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages =>
      filteredList.isEmpty ? 0 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username.");
      return;
    }

    if (mounted) setState(() => isDeleting = true);
    try {
      final res = await http
          .get(Uri.parse(
              'http://host.asta-official.my.id:9471/deleteUser?key=$sessionKey&username=$username'))
          .timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _cachedUserList = [];
        _fetchUsers(forceRefresh: true);
      } else {
        _alert("Gagal", data['message']?.toString() ?? 'Gagal menghapus user.');
      }
    } on TimeoutException {
      _alert("Error", "Koneksi ke server timeout. Coba lagi.");
    } on SocketException {
      _alert("Error", "Tidak ada koneksi internet.");
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    if (mounted) setState(() => isDeleting = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    if (u.contains(' ')) {
      _alert("Peringatan", "Username tidak boleh mengandung spasi.");
      return;
    }
    if (int.tryParse(d) == null || int.parse(d) <= 0) {
      _alert("Peringatan", "Durasi harus berupa angka lebih dari 0.");
      return;
    }

    if (mounted) setState(() => isCreating = true);
    try {
      final url = Uri.parse(
        'http://host.asta-official.my.id:9471/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=${newUserRole.toLowerCase()}',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        if (mounted) setState(() => newUserRole = 'MEMBER');
        _cachedUserList = [];
        _fetchUsers(forceRefresh: true);
      } else {
        _alert("Gagal", data['message']?.toString() ?? 'Gagal membuat akun.');
      }
    } on TimeoutException {
      _alert("Error", "Koneksi ke server timeout. Coba lagi.");
    } on SocketException {
      _alert("Error", "Tidak ada koneksi internet.");
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    if (mounted) setState(() => isCreating = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    if (int.tryParse(d) == null || int.parse(d) <= 0) {
      _alert("Peringatan", "Jumlah hari harus berupa angka lebih dari 0.");
      return;
    }

    if (mounted) setState(() => isEditing = true);
    try {
      final url = Uri.parse(
        'http://host.asta-official.my.id:9471/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _cachedUserList = [];
        _fetchUsers(forceRefresh: true);
      } else {
        _alert("Gagal", data['message']?.toString() ?? 'Gagal mengubah durasi.');
      }
    } on TimeoutException {
      _alert("Error", "Koneksi ke server timeout. Coba lagi.");
    } on SocketException {
      _alert("Error", "Tidak ada koneksi internet.");
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    if (mounted) setState(() => isEditing = false);
  }

  void _alert(String title, String message) {
    if (!mounted) return;
    final bool isSuccess = title.toLowerCase() == "sukses";
    final Color accent = isSuccess ? successGreen : accentPurple;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accent.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(
              isSuccess ? Icons.check_circle : Icons.info_outline,
              color: accent,
            ),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite)),
          ],
        ),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryBlue, accentPurple]),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  "OK",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- UI BUILDERS ----------

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: accentPurple),
          prefixIcon: Icon(icon, color: accentPurple),
          filled: true,
          fillColor: cardGlass,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentPurple, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildRoleDropdown({
    required String value,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGlass),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: bgDark,
          icon: Icon(Icons.keyboard_arrow_down_rounded, color: accentPurple),
          style: TextStyle(color: primaryWhite),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(_roleIcon(role), color: _roleColor(role), size: 14),
                  const SizedBox(width: 10),
                  Text("${role.toUpperCase()}${_roleLabel(role)}"),
                ],
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required List<Color> colors,
    required VoidCallback onPressed,
    bool loading = false,
  }) {
    return Container(
      height: 46,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: colors.first.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: loading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: loading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            : Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, size: 16, color: Colors.white),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.15),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [primaryBlue, accentPurple]),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    final String role = (user['role'] ?? '').toString();
    final bool isOwner = role.toLowerCase() == 'owner';
    final Color roleColor = _roleColor(role);
    final String username = (user['username'] ?? '-').toString();
    final String expiredDate = (user['expiredDate'] ?? '-').toString();

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: roleColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.18),
              shape: BoxShape.circle,
            ),
            child: Icon(_roleIcon(role), color: roleColor, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        username,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: primaryWhite,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    if (isOwner) ...[
                      const SizedBox(width: 4),
                      const Icon(Icons.verified, color: Colors.blueAccent, size: 14),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: roleColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(color: roleColor, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.schedule, color: textGrey, size: 11),
                    const SizedBox(width: 3),
                    Flexible(
                      child: Text(
                        expiredDate,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: textGrey, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: dangerRed.withOpacity(0.12),
              shape: BoxShape.circle,
              border: Border.all(color: dangerRed.withOpacity(0.3)),
            ),
            child: IconButton(
              icon: Icon(Icons.delete_outline, color: dangerRed, size: 18),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: bgDark,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: dangerRed.withOpacity(0.3)),
                    ),
                    title: Row(
                      children: [
                        Icon(Icons.warning_amber_rounded, color: dangerRed),
                        const SizedBox(width: 10),
                        Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                      ],
                    ),
                    content: Text("Hapus user \"$username\" ini?", style: TextStyle(color: textGrey)),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text("Batal", style: TextStyle(color: Color(0xFF4C6EF5))),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: Text("Hapus", style: TextStyle(color: dangerRed, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  deleteController.text = username;
                  _deleteUser();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();

    return Wrap(
      spacing: 6,
      runSpacing: 6,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final bool active = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: active ? LinearGradient(colors: [primaryBlue, accentPurple]) : null,
              color: active ? null : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: active ? Colors.transparent : borderGlass),
            ),
            child: Text(
              "$page",
              style: TextStyle(
                fontSize: 11,
                color: active ? Colors.white : Colors.white54,
                fontWeight: active ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, deepOcean, accentPurple.withOpacity(0.08), bgDark],
          ),
        ),
        child: SafeArea(
          child: isInitialLoad
              ? Center(
                  child: CircularProgressIndicator(color: accentPurple),
                )
              : RefreshIndicator(
                  color: accentPurple,
                  backgroundColor: bgDark,
                  onRefresh: () => _fetchUsers(forceRefresh: true),
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Header
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [accentPurple.withOpacity(0.2), primaryBlue.withOpacity(0.2)],
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: accentPurple.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [accentPurple, accentPink]),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 28),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "CEO-UTAMA",
                                      style: TextStyle(
                                        color: primaryWhite,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 2,
                                      ),
                                    ),
                                    Text(
                                      "Main CEO Dashboard",
                                      style: TextStyle(color: textGrey, fontSize: 12),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                decoration: BoxDecoration(
                                  color: accentPurple.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(color: accentPurple.withOpacity(0.3)),
                                ),
                                child: Text(
                                  "👑 ${fullUserList.length} Users",
                                  style: TextStyle(color: accentPurple, fontSize: 11, fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 8),
                              InkWell(
                                borderRadius: BorderRadius.circular(20),
                                onTap: isLoading ? null : () => _fetchUsers(forceRefresh: true),
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: primaryBlue.withOpacity(0.25),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.refresh, color: primaryWhite, size: 16),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        // DELETE USER
                        _buildGlassCard(
                          title: "DELETE USER",
                          icon: FontAwesomeIcons.userSlash,
                          children: [
                            _buildInput(
                              label: "Username Target",
                              controller: deleteController,
                              icon: FontAwesomeIcons.user,
                            ),
                            const SizedBox(height: 8),
                            _buildActionButton(
                              label: "DELETE ACCOUNT",
                              icon: Icons.delete,
                              colors: [dangerRed, Colors.red.shade900],
                              onPressed: _deleteUser,
                              loading: isDeleting,
                            ),
                          ],
                        ),

                        // CREATE ACCOUNT
                        _buildGlassCard(
                          title: "CREATE ACCOUNT",
                          icon: FontAwesomeIcons.userPlus,
                          children: [
                            _buildInput(
                              label: "Username",
                              controller: createUsernameController,
                              icon: FontAwesomeIcons.user,
                            ),
                            _buildInput(
                              label: "Password",
                              controller: createPasswordController,
                              icon: FontAwesomeIcons.lock,
                            ),
                            _buildInput(
                              label: "Durasi (Hari)",
                              controller: createDayController,
                              icon: FontAwesomeIcons.calendarDay,
                              type: TextInputType.number,
                            ),
                            _buildRoleDropdown(
                              value: newUserRole,
                              onChanged: (val) => setState(() => newUserRole = val ?? 'MEMBER'),
                            ),
                            const SizedBox(height: 16),
                            _buildActionButton(
                              label: "CREATE ACCOUNT",
                              icon: Icons.person_add_alt_1,
                              colors: [primaryBlue, accentPurple],
                              onPressed: _createAccount,
                              loading: isCreating,
                            ),
                          ],
                        ),

                        // EXTEND DURATION
                        _buildGlassCard(
                          title: "EXTEND DURATION",
                          icon: FontAwesomeIcons.clock,
                          children: [
                            _buildInput(
                              label: "Username Target",
                              controller: editUsernameController,
                              icon: FontAwesomeIcons.userEdit,
                            ),
                            _buildInput(
                              label: "Tambah Hari",
                              controller: editDayController,
                              icon: FontAwesomeIcons.calendarPlus,
                              type: TextInputType.number,
                            ),
                            const SizedBox(height: 8),
                            _buildActionButton(
                              label: "ADD DAYS",
                              icon: Icons.add_circle_outline,
                              colors: [accentPurple, primaryBlue],
                              onPressed: _editUser,
                              loading: isEditing,
                            ),
                          ],
                        ),

                        // USER LIST
                        _buildGlassCard(
                          title: "USER LIST",
                          icon: FontAwesomeIcons.users,
                          children: [
                            _buildRoleDropdown(
                              value: selectedRole,
                              onChanged: (val) {
                                if (val != null) {
                                  setState(() => selectedRole = val);
                                  _filterAndPaginate();
                                }
                              },
                            ),
                            const SizedBox(height: 14),
                            if (isLoading)
                              Center(child: CircularProgressIndicator(color: accentPurple))
                            else if (filteredList.isEmpty)
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(20),
                                  child: Column(
                                    children: [
                                      Icon(Icons.inbox_outlined, color: textGrey, size: 32),
                                      const SizedBox(height: 8),
                                      Text(
                                        "Tidak ada user dengan role ini",
                                        style: TextStyle(color: textGrey),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            else
                              Column(
                                children: [
                                  ..._getCurrentPageData().map((u) => _buildUserItem(u)),
                                  const SizedBox(height: 12),
                                  _buildPagination(),
                                ],
                              ),
                          ],
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}
