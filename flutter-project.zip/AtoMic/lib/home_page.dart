import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;
  
  String _selectedBugMode = "number";
  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;

  static const Color bgMain = Color(0xFF0D1117);
  static const Color bgCard = Color(0xFF161B22);
  static const Color bgSurface = Color(0xFF1C2333);
  static const Color accentColor = Color(0xFF00E5FF);
  static const Color textMain = Color(0xFFE6EDF3);
  static const Color textSub = Color(0xFF8B949E);
  static const Color borderColor = Color(0xFF30363D);

  @override
  void initState() {
    super.initState();
    
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() {});
          _videoController?.setVolume(1.0);
          _videoController?.setLooping(true);
          _videoController?.play();
        }
      }).catchError((e) {
        debugPrint("Video error: $e");
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }
    _fetchSenderStats();
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://panelpakekwoingen.ajengfeb.my.id:2078/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          if (mounted) {
            setState(() {
              _privateSenderCount = data['private'] ?? 0;
              _globalSenderCount = data['global'] ?? 0;
            });
          }
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.isEmpty || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid.");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia.");
        return;
      }
    }

    setState(() => _isSending = true);

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip' || widget.role == 'moderator')
        ? _senderMode
        : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://panelpakekwoingen.ajengfeb.my.id:2078/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi tidak valid.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server error.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan.");
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
      }
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    CustomPopup.show(
      context,
      title: title,
      message: msg,
      icon: title.contains("✅") ? Icons.check_circle_outline : Icons.error_outline,
      iconColor: title.contains("✅") ? Colors.green : Colors.redAccent,
      confirmText: "Close",
    );
  }

  Widget _buildAccountOverlay() {
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return Container(
        decoration: BoxDecoration(
          color: bgSurface,
          borderRadius: BorderRadius.circular(18),
        ),
        child: const Center(
          child: CircularProgressIndicator(color: accentColor),
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: VideoPlayer(_videoController!),
        ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              begin: Alignment.bottomLeft,
              end: Alignment.topRight,
              colors: [Colors.black.withOpacity(0.7), Colors.black.withOpacity(0.2)],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.username.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: accentColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: accentColor.withOpacity(0.4), width: 0.8),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: accentColor.withOpacity(0.3), width: 0.8),
                    ),
                    child: Icon(Icons.check_circle_outline, color: accentColor, size: 20),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "SISA MASA BERLAKU",
                        style: TextStyle(
                          color: textSub,
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        widget.expiredDate,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "STATUS",
                        style: TextStyle(
                          color: textSub,
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.green.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.green.withOpacity(0.5), width: 0.8),
                        ),
                        child: const Text(
                          "ACTIVE",
                          style: TextStyle(
                            color: Colors.green,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _cleanBugName(String bugName) {
    return bugName
        .replaceAll(RegExp(r'^bug_|_group$'), '')
        .replaceAll('_', ' ')
        .toUpperCase();
  }

  String _getBugStatus(String bugId) {
    final list = ['ARMED', 'STANDBY', 'ACTIVE', 'READY'];
    final index = bugId.length % list.length;
    return list[index];
  }

  Widget _buildPayloadList(List<Map<String, dynamic>> availableBugs) {
    if (availableBugs.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: bgSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor, width: 1),
        ),
        child: Center(
          child: Text(
            "Tidak ada payload",
            style: TextStyle(color: textSub),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 12),
          child: Text(
            "SELECT PAYLOAD",
            style: TextStyle(
              color: textSub,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: bgSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderColor, width: 1),
          ),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Column(
            children: availableBugs.asMap().entries.map((entry) {
              final idx = entry.key;
              final bug = entry.value;
              final isSelected = bug['bug_id'] == selectedBugId;
              final status = _getBugStatus(bug['bug_id']);
              final isArmed = status == 'ARMED';
              final bugName = _cleanBugName(bug['bug_name'] ?? 'Unknown');

              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedBugId = bug['bug_id'];
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: isSelected ? accentColor.withOpacity(0.08) : Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.circle_outlined,
                        color: isSelected ? accentColor : borderColor,
                        size: 16,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              bugName,
                              style: TextStyle(
                                color: isSelected ? accentColor : textMain,
                                fontSize: 13,
                                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                            if (idx == 0) ...[
                              const SizedBox(height: 2),
                              Text(
                                "ID: ${bug['bug_id'] ?? 'Function1'}",
                                style: TextStyle(
                                  color: textSub,
                                  fontSize: 10,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: isArmed 
                              ? Colors.green.withOpacity(0.15) 
                              : Colors.orange.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: isArmed 
                                ? Colors.green.withOpacity(0.4) 
                                : Colors.orange.withOpacity(0.4),
                            width: 0.8,
                          ),
                        ),
                        child: Text(
                          status,
                          style: TextStyle(
                            color: isArmed ? Colors.green : Colors.orange,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text(
            "PAYLOAD PREVIEW",
            style: TextStyle(
              color: accentColor,
              fontWeight: FontWeight.w900,
              fontSize: 16,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ),
        Row(
          children: [
            _buildModeChip(
              label: "BUG NOMOR",
              isSelected: _selectedBugMode == "number",
              onTap: () {
                setState(() {
                  _selectedBugMode = "number";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) {
                    selectedBugId = newBugs[0]['bug_id'];
                  }
                });
              },
            ),
            const SizedBox(width: 12),
            _buildModeChip(
              label: "BUG GROUP",
              isSelected: _selectedBugMode == "group",
              onTap: () {
                setState(() {
                  _selectedBugMode = "group";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) {
                    selectedBugId = newBugs[0]['bug_id'];
                  }
                });
              },
            ),
          ],
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
            style: TextStyle(
              color: textSub,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        TextField(
          controller: targetController,
          style: TextStyle(color: textMain, fontSize: 16),
          cursorColor: accentColor,
          keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number"
                ? "+628xxxxxxxxxxx"
                : "https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: textSub.withOpacity(0.4)),
            filled: true,
            fillColor: bgSurface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: borderColor, width: 1.2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: borderColor, width: 1.2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: accentColor, width: 1.3),
            ),
            prefixIcon: Icon(
              _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
              color: textSub,
            ),
            contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
          ),
        ),
        const SizedBox(height: 20),
        _buildPayloadList(availableBugs),
      ],
    );
  }

  Widget _buildModeChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? accentColor.withOpacity(0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? accentColor : borderColor,
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: isSelected ? accentColor : textSub,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                fontSize: 13,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return _PressableScale(
          child: Container(
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: accentColor, width: 1.5),
              color: accentColor.withOpacity(0.1),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.2 * _pulseController.value),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isSending ? null : _sendBug,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
                shadowColor: Colors.transparent,
              ),
              child: _isSending
                  ? SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: accentColor,
                        strokeWidth: 2,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_outlined, color: accentColor, size: 20),
                        const SizedBox(width: 10),
                        Text(
                          "LAUNCH",
                          style: TextStyle(
                            color: accentColor,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 2.5,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSenderModeSection() {
    if (widget.role != 'owner' && widget.role != 'vip' && widget.role != 'moderator') {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 20),
        Divider(color: borderColor, height: 1),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            "SENDER MODE",
            style: TextStyle(
              color: textSub,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: _buildSenderModeButton(
                label: "PRIVATE",
                icon: Icons.person_outline,
                count: _privateSenderCount,
                isSelected: _senderMode == 'private',
                onTap: () => setState(() => _senderMode = 'private'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildSenderModeButton(
                label: "GLOBAL",
                icon: Icons.public,
                count: _globalSenderCount,
                isSelected: _senderMode == 'global',
                onTap: () => setState(() => _senderMode = 'global'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSenderModeButton({
    required String label,
    required IconData icon,
    required int count,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return _PressableScale(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected ? accentColor.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? accentColor : borderColor,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected ? accentColor : textSub,
              size: 18,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? accentColor : textSub,
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                fontFamily: 'Orbitron',
                letterSpacing: 0.6,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              count.toString(),
              style: TextStyle(
                color: isSelected ? accentColor : textSub,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavItem(Icons.home_outlined, "HOME", true),
          _buildNavItem(Icons.chat_outlined, "WA", false),
          _buildNavItem(Icons.info_outline, "INFO", false),
          _buildNavItem(Icons.music_note_outlined, "VIBES", false),
          _buildNavItem(Icons.build_outline, "TOOLS", false),
        ],
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return GestureDetector(
      onTap: () {},
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: isActive ? accentColor : textSub,
            size: 22,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? accentColor : textSub,
              fontSize: 10,
              fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: borderColor, width: 1.2),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: _buildAccountOverlay(),
                ),
              ),
              const SizedBox(height: 18),
              _buildInputPanel(),
              const SizedBox(height: 24),
              _buildSendButton(),
              _buildSenderModeSection(),
              _buildBottomNav(),
            ],
          ),
        ),
      ),
    );
  }
}

class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const _PressableScale({required this.child, this.onTap});

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale> {
  double _scale = 1.0;

  void _setPressed(bool pressed) {
    if (!mounted) return;
    setState(() => _scale = pressed ? 0.96 : 1.0);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedScale(
          scale: _scale,
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      ),
    );
  }
}