import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class GlobalChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String androidId; // ← FIX: wajib kirim androidId ke validate

  const GlobalChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.androidId,
  });

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage>
    with SingleTickerProviderStateMixin {
  // --- TEMA WARNA (sama dengan dashboard) ---
  static const Color bgMain = Color(0xFFDCEEFB);
  static const Color bgSurface = Color(0xFFFFFFFF);
  static const Color bgCard = Color(0xFFF0F7FF);
  static const Color textMain = Colors.black87;
  static const Color textSub = Colors.black54;
  static const Color accentBlue = Color(0xFF1565C0);
  static const Color borderBlue = Color(0xFF42A5F5);

  late WebSocketChannel _channel;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isConnected = false;
  bool _isConnecting = true;
  int _onlineCount = 0;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut);
    _fadeController.forward();
    _connectWebSocket();
  }

  void _connectWebSocket() {
    if (mounted) setState(() { _isConnecting = true; _isConnected = false; });
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('ws://panelpakekwoingen.ajengfeb.my.id:2078'),
      );

      // FIX: kirim androidId agar backend tidak disconnect saat cek validId
      _channel.sink.add(jsonEncode({
        "type": "validate",
        "key": widget.sessionKey,
        "androidId": widget.androidId,
      }));

      _channel.stream.listen(
        (event) {
          if (!mounted) return;
          final data = jsonDecode(event);

          // ── Hasil validate ─────────────────────────────────
          if (data['type'] == 'myInfo') {
            if (data['valid'] == true) {
              // Validasi sukses → sekarang join room
              _channel.sink.add(jsonEncode({
                "type": "joinChat",
                "room": "global",
                "username": widget.username,
              }));
              _channel.sink.add(jsonEncode({"type": "stats"}));
            } else {
              // Key tidak valid / androidId mismatch
              setState(() { _isConnected = false; _isConnecting = false; });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Sesi tidak valid, silakan login ulang.')),
              );
              Navigator.pop(context);
            }
            return;
          }

          // ── Force logout dari server ────────────────────────
          if (data['type'] == 'forceLogout') {
            setState(() { _isConnected = false; _isConnecting = false; });
            Navigator.pop(context);
            return;
          }

          // ── Stats ───────────────────────────────────────────
          if (data['type'] == 'stats') {
            setState(() => _onlineCount = data['onlineUsers'] ?? 0);
          }

          // ── Chat history → tandai connected ────────────────
          if (data['type'] == 'chatHistory' && data['room'] == 'global') {
            final history = data['messages'] as List<dynamic>? ?? [];
            setState(() {
              _isConnected = true;
              _isConnecting = false;
              _messages.clear();
              for (final msg in history) {
                _messages.add({
                  'username': msg['username'] ?? 'Unknown',
                  'message': msg['message'] ?? '',
                  'timestamp': msg['timestamp'] ?? '',
                  'isSelf': msg['username'] == widget.username,
                });
              }
            });
            Future.delayed(const Duration(milliseconds: 100), _scrollToBottom);
          }

          // ── Pesan baru masuk ────────────────────────────────
          if (data['type'] == 'chatMessage' && data['room'] == 'global') {
            setState(() {
              _isConnected = true;
              _isConnecting = false;
              _messages.add({
                'username': data['username'] ?? 'Unknown',
                'message': data['message'] ?? '',
                'timestamp': data['timestamp'] ?? DateTime.now().toIso8601String(),
                'isSelf': data['username'] == widget.username,
              });
            });
            _scrollToBottom();
          }

          // ── User join ───────────────────────────────────────
          if (data['type'] == 'userJoined' && data['room'] == 'global') {
            setState(() {
              _isConnected = true;
              _isConnecting = false;
              _onlineCount = data['onlineInRoom'] ?? _onlineCount;
              _messages.add({
                'username': '',
                'message': '${data['username']} joined the chat',
                'timestamp': DateTime.now().toIso8601String(),
                'isSelf': false,
                'isSystem': true,
              });
            });
            _scrollToBottom();
          }

          // ── User left ───────────────────────────────────────
          if (data['type'] == 'userLeft' && data['room'] == 'global') {
            setState(() {
              _onlineCount = data['onlineInRoom'] ?? _onlineCount;
              _messages.add({
                'username': '',
                'message': '${data['username']} left the chat',
                'timestamp': DateTime.now().toIso8601String(),
                'isSelf': false,
                'isSystem': true,
              });
            });
            _scrollToBottom();
          }
        },
        onError: (_) {
          if (mounted) setState(() { _isConnected = false; _isConnecting = false; });
        },
        onDone: () {
          if (mounted) setState(() { _isConnected = false; _isConnecting = false; });
        },
      );
    } catch (_) {
      if (mounted) setState(() { _isConnected = false; _isConnecting = false; });
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty || !_isConnected) return;

    _channel.sink.add(jsonEncode({
      "type": "chatMessage",
      "room": "global",
      "username": widget.username,
      "message": text,
    }));

    _messageController.clear();
  }

  void _reconnect() {
    try { _channel.sink.close(status.goingAway); } catch (_) {}
    _connectWebSocket();
  }

  String _formatTime(String timestamp) {
    try {
      final dt = DateTime.parse(timestamp).toLocal();
      final h = dt.hour.toString().padLeft(2, '0');
      final m = dt.minute.toString().padLeft(2, '0');
      return '$h:$m';
    } catch (_) { return ''; }
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _fadeController.dispose();
    try { _channel.sink.close(status.goingAway); } catch (_) {}
    super.dispose();
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: _buildAppBar(),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            _buildStatusBar(),
            Expanded(child: _buildMessageList()),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      automaticallyImplyLeading: true,
      backgroundColor: bgSurface,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: textMain, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: accentBlue.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.groups_2_rounded, color: accentBlue, size: 20),
          ),
          const SizedBox(width: 10),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "GLOBAL CHAT",
                style: TextStyle(
                  color: textMain,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                "AtoMic Community",
                style: TextStyle(
                  color: textSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1.5),
        child: Container(height: 1.5, color: Colors.black),
      ),
      actions: [
        if (!_isConnected && !_isConnecting)
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: accentBlue),
            tooltip: 'Reconnect',
            onPressed: _reconnect,
          ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildStatusBar() {
    Color dotColor;
    String label;

    if (_isConnecting) {
      dotColor = Colors.orange;
      label = "Connecting...";
    } else if (_isConnected) {
      dotColor = Colors.green;
      label = "$_onlineCount online";
    } else {
      dotColor = Colors.red;
      label = "Disconnected";
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: const BoxDecoration(
        color: bgCard,
        border: Border(bottom: BorderSide(color: Colors.black26, width: 1)),
      ),
      child: Row(
        children: [
          _AnimatedDot(color: dotColor),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: textSub, fontSize: 12, fontFamily: 'ShareTechMono')),
          const Spacer(),
          if (_isConnected)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: accentBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentBlue.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.lock_open_rounded, size: 11, color: accentBlue),
                  SizedBox(width: 4),
                  Text("Public Room", style: TextStyle(color: accentBlue, fontSize: 10.5, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    if (_isConnecting) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: accentBlue, strokeWidth: 2.5),
            SizedBox(height: 16),
            Text("Connecting to Global Chat...", style: TextStyle(color: textSub, fontFamily: 'ShareTechMono', fontSize: 13)),
          ],
        ),
      );
    }

    if (!_isConnected && _messages.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: bgCard,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 1.5),
                boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(3, 3))],
              ),
              child: const Icon(Icons.wifi_off_rounded, color: textSub, size: 36),
            ),
            const SizedBox(height: 16),
            const Text("Failed to connect", style: TextStyle(color: textMain, fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            const Text("Tap refresh to try again", style: TextStyle(color: textSub, fontSize: 13)),
          ],
        ),
      );
    }

    if (_messages.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.chat_bubble_outline_rounded, color: borderBlue, size: 48),
            SizedBox(height: 12),
            Text("No messages yet", style: TextStyle(color: textSub, fontSize: 14)),
            SizedBox(height: 4),
            Text("Be the first to say something!", style: TextStyle(color: textSub, fontSize: 12)),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final msg = _messages[index];
        if (msg['isSystem'] == true) return _buildSystemMessage(msg['message']);
        return _buildChatBubble(msg, index);
      },
    );
  }

  Widget _buildSystemMessage(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.06),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(text, style: const TextStyle(color: textSub, fontSize: 11.5, fontFamily: 'ShareTechMono')),
        ),
      ),
    );
  }

  Widget _buildChatBubble(Map<String, dynamic> msg, int index) {
    final bool isSelf = msg['isSelf'] == true;
    final String username = msg['username'] ?? '';
    final String message = msg['message'] ?? '';
    final String time = _formatTime(msg['timestamp'] ?? '');

    bool showHeader = true;
    if (!isSelf && index > 0) {
      final prev = _messages[index - 1];
      if (prev['isSystem'] != true && prev['isSelf'] != true && prev['username'] == username) {
        showHeader = false;
      }
    }

    return Padding(
      padding: EdgeInsets.only(top: showHeader ? 10 : 2, bottom: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isSelf ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isSelf) ...[
            if (showHeader)
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: accentBlue.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 1.2),
                ),
                child: const Icon(Icons.person_rounded, size: 18, color: accentBlue),
              )
            else
              const SizedBox(width: 34),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isSelf ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (!isSelf && showHeader)
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 4),
                    child: Text(
                      username,
                      style: const TextStyle(color: accentBlue, fontWeight: FontWeight.w800, fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 0.3),
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.65),
                  decoration: BoxDecoration(
                    color: isSelf ? accentBlue : bgSurface,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isSelf ? 16 : 4),
                      bottomRight: Radius.circular(isSelf ? 4 : 16),
                    ),
                    border: Border.all(color: Colors.black, width: 1.2),
                    boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(2, 2))],
                  ),
                  child: Text(message, style: TextStyle(color: isSelf ? Colors.white : textMain, fontSize: 14, height: 1.4)),
                ),
                const SizedBox(height: 3),
                Text(time, style: const TextStyle(color: textSub, fontSize: 10, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
          if (isSelf) const SizedBox(width: 4),
        ],
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
      decoration: const BoxDecoration(
        color: bgSurface,
        border: Border(top: BorderSide(color: Colors.black, width: 1.5)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, -2))],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: bgCard,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.black, width: 1.2),
                  boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(2, 2))],
                ),
                child: TextField(
                  controller: _messageController,
                  enabled: _isConnected,
                  maxLines: null,
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.newline,
                  style: const TextStyle(color: textMain, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: _isConnected ? "Type a message..." : "Not connected",
                    hintStyle: const TextStyle(color: textSub, fontSize: 14),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  ),
                  onSubmitted: (_) => _sendMessage(),
                ),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: _isConnected ? _sendMessage : null,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: _isConnected ? accentBlue : Colors.grey.shade300,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 1.2),
                  boxShadow: _isConnected
                      ? const [BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(2, 2))]
                      : null,
                ),
                child: Icon(Icons.send_rounded, color: _isConnected ? Colors.white : Colors.grey, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// ANIMATED STATUS DOT
// ================================================================

class _AnimatedDot extends StatefulWidget {
  final Color color;
  const _AnimatedDot({required this.color});

  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(duration: const Duration(milliseconds: 900), vsync: this)
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: widget.color.withOpacity(_anim.value),
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: widget.color.withOpacity(_anim.value * 0.6), blurRadius: 4, spreadRadius: 1)],
        ),
      ),
    );
  }
}
